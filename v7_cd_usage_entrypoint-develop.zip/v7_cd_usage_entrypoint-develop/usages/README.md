# Référencement des usages par GEA

Un usage est autorisé uniquement si le dossier suivant existe :

```text
usages/<NAME>/params.json
```

Exemple :

```text
usages/ma-dsd-sinbdo-domsin/params.json
```

Contenu minimal :

```json
{
  "dev": "caa-data-domsin-dev-e7",
  "int": "caa-data-domsin-int-ca",
  "rec": "caa-data-domsin-rec-ee"
}
```

Les manifests sont générés automatiquement par le pipeline :

```text
usages/<NAME>/manifests/dev.json
usages/<NAME>/manifests/int.json
usages/<NAME>/manifests/rec.json
```
