#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

: "${TARGET_ENVIRONMENT:?Variable obligatoire manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable obligatoire manquante: NAME}"

case "${TARGET_ENVIRONMENT}" in
  dev|int|rec) ;;
  *) fail "TARGET_ENVIRONMENT invalide: ${TARGET_ENVIRONMENT}. Valeurs autorisées: dev, int, rec" ;;
esac

if [ ! -d "usages/${NAME}" ]; then
  fail "Usage non référencé par GEA: usages/${NAME} n'existe pas. GEA doit créer le dossier et le params.json avant le déploiement."
fi

if [ ! -f "usages/${NAME}/params.json" ]; then
  fail "Usage non référencé par GEA: usages/${NAME}/params.json est manquant."
fi

if ! jq empty "usages/${NAME}/params.json" >/dev/null 2>&1; then
  fail "JSON invalide: usages/${NAME}/params.json"
fi

if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
  : "${GROUP_ID:?Variable obligatoire manquante en dev: GROUP_ID}"
  : "${VERSION:?Variable obligatoire manquante en dev: VERSION}"
fi

if [ "${TARGET_ENVIRONMENT}" != "dev" ] && [ ! -f "usages/${NAME}/manifests/dev.json" ]; then
  fail "manifests/dev.json est requis pour déployer ${TARGET_ENVIRONMENT}. Lancez d'abord un déploiement dev ou créez le manifest dev de référence."
fi

echo "Validation OK pour NAME=${NAME}, TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
