#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

PARAMS_FILE="usages/${NAME}/params.json"
TARGET_PROJECT="$(jq -r --arg env "${TARGET_ENVIRONMENT}" '.[$env] // empty' "${PARAMS_FILE}")"

if [ -z "${TARGET_PROJECT}" ]; then
  fail "Aucun project_id trouvé pour env=${TARGET_ENVIRONMENT} dans ${PARAMS_FILE}"
fi

SOURCE_REPOSITORY="staging"
if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
  SOURCE_REPOSITORY="scratch"
  RESOLVED_GROUP_ID="${GROUP_ID}"
  RESOLVED_VERSION="${VERSION}"
else
  DEV_MANIFEST="usages/${NAME}/manifests/dev.json"
  [ -f "${DEV_MANIFEST}" ] || fail "Manifest dev introuvable: ${DEV_MANIFEST}"

  DEV_GROUP_ID="$(jq -r '.groupId // empty' "${DEV_MANIFEST}")"
  DEV_VERSION="$(jq -r '.version // empty' "${DEV_MANIFEST}")"

  [ -n "${DEV_GROUP_ID}" ] || fail "groupId absent dans ${DEV_MANIFEST}"
  [ -n "${DEV_VERSION}" ] || fail "version absente dans ${DEV_MANIFEST}"

  # En int/rec, GROUP_ID et VERSION sont optionnels et surchargent dev.json si fournis.
  RESOLVED_GROUP_ID="${GROUP_ID:-${DEV_GROUP_ID}}"
  RESOLVED_VERSION="${VERSION:-${DEV_VERSION}}"
fi

MANIFEST_PATH="usages/${NAME}/manifests/${TARGET_ENVIRONMENT}.json"

mkdir -p "$(dirname "${MANIFEST_PATH}")"

cat > deploy.env <<EOF
GROUP_ID=${RESOLVED_GROUP_ID}
NAME=${NAME}
VERSION=${RESOLVED_VERSION}
TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}
TARGET_PROJECT=${TARGET_PROJECT}
SOURCE_REPOSITORY=${SOURCE_REPOSITORY}
MANIFEST_PATH=${MANIFEST_PATH}
EOF

cat > "${MANIFEST_PATH}.tmp" <<EOF
{
  "groupId": "${RESOLVED_GROUP_ID}",
  "name": "${NAME}",
  "version": "${RESOLVED_VERSION}",
  "targetEnvironment": "${TARGET_ENVIRONMENT}",
  "targetProject": "${TARGET_PROJECT}",
  "sourceRepository": "${SOURCE_REPOSITORY}"
}
EOF

jq . "${MANIFEST_PATH}.tmp" > "${MANIFEST_PATH}.resolved"
rm -f "${MANIFEST_PATH}.tmp"

echo "Manifest résolu: ${MANIFEST_PATH}"
echo "GROUP_ID=${RESOLVED_GROUP_ID}"
echo "VERSION=${RESOLVED_VERSION}"
echo "TARGET_PROJECT=${TARGET_PROJECT}"
echo "SOURCE_REPOSITORY=${SOURCE_REPOSITORY}"
