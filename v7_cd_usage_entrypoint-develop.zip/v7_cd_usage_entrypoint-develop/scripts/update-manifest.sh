#!/usr/bin/env bash
set -euo pipefail

source deploy.env

mkdir -p "$(dirname "${MANIFEST_PATH}")"
mv "${MANIFEST_PATH}.resolved" "${MANIFEST_PATH}"

git config user.email "gitlab-ci@cagip.local"
git config user.name "GitLab CI"

git add "${MANIFEST_PATH}"

if git diff --cached --quiet; then
  echo "Aucun changement à commiter pour ${MANIFEST_PATH}"
  exit 0
fi

if [ -z "${GIT_PUSH_TOKEN:-}" ]; then
  echo "ERREUR - GIT_PUSH_TOKEN est requis pour commiter le manifest" >&2
  exit 1
fi

git commit -m "Update manifest ${NAME} ${TARGET_ENVIRONMENT} ${VERSION} [skip ci]"

git pull --rebase "https://oauth2:${GIT_PUSH_TOKEN}@${CI_SERVER_HOST}/${CI_PROJECT_PATH}.git" "${CI_COMMIT_REF_NAME}"
git push "https://oauth2:${GIT_PUSH_TOKEN}@${CI_SERVER_HOST}/${CI_PROJECT_PATH}.git" "HEAD:${CI_COMMIT_REF_NAME}"
