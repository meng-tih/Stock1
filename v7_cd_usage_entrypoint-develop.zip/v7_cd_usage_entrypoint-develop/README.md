# v7_cd_usage_entrypoint

Repo d'entrée CD pour les usages applicatifs CAAS.

## Rôle

Ce repo :

1. reçoit l'appel des repoS CI applicatifs CAAS ;
2. contrôle que l'usage a été référencé par GEA ;
3. lit le `project_id` cible dans `usages/<NAME>/params.json` ;
4. crée ou met à jour le manifest de l'environnement ;
5. déclenche le repo `v7_cd_usage`.

Il ne fait aucun déploiement GCP.

## Structure

```text
usages/
  <NAME>/
    params.json
    manifests/
      dev.json
      int.json
      rec.json
```

Le dossier `usages/<NAME>/` et le fichier `params.json` sont créés manuellement par GEA.

## Exemple `params.json`

```json
{
  "dev": "caa-data-domsin-dev-e7",
  "int": "caa-data-domsin-int-ca",
  "rec": "caa-data-domsin-rec-ee"
}
```

## Variables d'entrée

### Dev

Obligatoires :

```text
TARGET_ENVIRONMENT=dev
NAME=<usage>
GROUP_ID=<groupId>
VERSION=<tag image>
```

### Int / Rec

Obligatoires :

```text
TARGET_ENVIRONMENT=int|rec
NAME=<usage>
```

Optionnelles :

```text
GROUP_ID=<surcharge>
VERSION=<surcharge>
```

Si `GROUP_ID` ou `VERSION` ne sont pas fournis en `int` / `rec`, les valeurs sont reprises depuis `manifests/dev.json`.

## Variables GitLab à configurer dans ce repo

```text
GIT_PUSH_TOKEN
CD_USAGE_TRIGGER_TOKEN
CD_USAGE_PROJECT_ID
CD_USAGE_REF
DOCKER_HUB_MIRROR
```

`CD_USAGE_REF` vaut `main` par défaut.

## Repository source image

```text
dev     -> scratch
int/rec -> staging
```
