# Kestra Management — Module Terraform `kmanager`

Outil de gestion **as Code** des ressources Kestra via un fichier JSON de configuration.
Un seul `terraform apply` crée, met à jour ou détruit les ressources d'un tenant Kestra.

---

> ## ⚠️ IMPORTANT — À LIRE AVANT TOUTE ACTION
>
> **Ne jamais modifier les ressources Kestra manuellement via l'interface ou l'API.**
>
> Le fichier `kestra-config-{tenant_id}.json` est l'unique source de vérité de la configuration d'un tenant.
> Tout ce qui n'est pas déclaré dans ce fichier et géré par Terraform **sera perdu** en cas de destruction et reconstruction de l'environnement.
>
> Cela inclut : les groupes, les rôles, les namespaces, les bindings et les service accounts.
>
> **Toute modification doit passer par le fichier JSON + `terraform apply`.**
> En cas de groupe créé manuellement que vous souhaitez référencer dans des bindings sans le confier à Terraform, utilisez la section `external_groups`.

---

## 🎯 Principe de fonctionnement

```
fichier JSON
    │
    ▼
terraform apply
    ├─ script get_kestra_resources.sh  ──► API Kestra  ──► détecte les ressources existantes
    ├─ crée ce qui est absent de Kestra
    ├─ ignore ce qui existe déjà (tenant, namespaces)
    └─ résout les UIDs des groupes externes pour les bindings
```

**Le module interroge l'API Kestra avant chaque apply** via le script `get_kestra_resources.sh` pour détecter ce qui existe déjà. Ainsi :

- Le **tenant** n'est créé que s'il est absent de Kestra
- Les **namespaces** déclarés dans le JSON ne sont créés que s'ils sont absents de Kestra
- Les **groupes** dans `groups` sont gérés par Terraform (créés, modifiés, détruits)
- Les **groupes** dans `external_groups` ne sont jamais créés ni détruits par Terraform — ils existent hors TF et leur UID est résolu via l'API pour être utilisé dans les bindings

---

## 📋 Prérequis

```bash
export VAULT_ROLE_ID="votre-role-id"
export VAULT_SECRET_ID="votre-secret-id"
```

---

## 🗄️ Configuration du backend Terraform (tf.state)

Le state Terraform est stocké dans un bucket GCS, **un state par tenant**.
Le bucket et le prefix sont configurés automatiquement par le script `deploy_tf_module.sh`.

### Bucket GCS

Le bucket est dérivé des variables du fichier `.tfvars` selon le pattern :

```
{project_name}-gcs-{region}-state-{ptf_name}
```

Exemple pour ISIS :
```
cagip-kestra-hprd-8b-gcs-europe-west1-state-kestra-hprd
```

> Le bucket est créé automatiquement s'il n'existe pas encore.

### Prefix (isolation par tenant)

Chaque tenant dispose de son propre prefix dans le bucket :

```
kmanager/tenant/{tenant_id}
```

Exemple :
```
kmanager/tenant/isis
kmanager/tenant/cagip
kmanager/tenant/geoffrey
```

Cela signifie que les states de différents tenants sont **complètement isolés** — un `terraform apply` sur `isis` n'affecte jamais le state de `cagip`.

### Si vous devez initialiser manuellement

Si vous devez lancer `terraform init` sans passer par `deploy_tf_module.sh` :

```bash
cd gcp/terraform/modules/kmanager
terraform init \
  -backend-config="bucket={project_name}-gcs-{region}-state-{ptf_name}" \
  -backend-config="prefix=kmanager/tenant/{tenant_id}"
```

---

## 🚀 Déploiement

```bash
cd gcp/scripts
source ./isis.sh
./deploy_tf_module.sh kmanager $(pwd)/../terraform/instanciation/"${instanciation}".tfvars
```

Le script détecte automatiquement les fichiers `kestra-config-*.json` présents dans le dossier `jsonconfig/`. S'il y en a plusieurs, un menu interactif vous propose de choisir le tenant à déployer.

---

## 📁 Nomenclature des fichiers JSON

Les fichiers de configuration doivent être placés dans :

```
gcp/terraform/instanciation/{plateforme}/{instance}/{tenant}/jsonconfig/
```

Le nom du fichier **doit** suivre la convention :

```
kestra-config-{tenant_id}.json
```

Exemples :
```
kestra-config-isis.json
kestra-config-cagip.json
kestra-config-geoffrey.json
```

> ⚠️ Le `tenant_id` dans le nom du fichier doit correspondre au `tenant_id` déclaré dans la section `tenant` du JSON.

---

## 📄 Structure du fichier JSON

Toutes les sections sont **optionnelles**, à l'exception de `tenant` qui est nécessaire pour identifier sur quel tenant Kestra les ressources sont créées.

```json
{
  "tenant":           { ... },   // requis — identifie le tenant cible
  "namespaces":       [ ... ],   // optionnel — namespaces à créer
  "roles":            [ ... ],   // optionnel — rôles à créer
  "groups":           [ ... ],   // optionnel — groupes gérés par Terraform
  "external_groups":  [ ... ],   // optionnel — groupes existants hors Terraform
  "service_accounts": [ ... ],   // optionnel — service accounts + tokens
  "bindings":         [ ... ]    // optionnel — associations groupe → rôle
}
```

---

## 🔑 Référence des sections

### `tenant` — Requis

Identifie le tenant Kestra cible.

```json
"tenant": {
  "tenant_id": "isis",      // ✅ requis
  "label":     "Isis Tenant", // ❌ optionnel
  "existing":  true           // ❌ optionnel — à mettre si le tenant existe déjà dans Kestra
}
```

| Champ | Requis | Description |
|---|---|---|
| `tenant_id` | ✅ | Identifiant unique du tenant dans Kestra |
| `label` | ❌ | Nom affiché dans l'interface Kestra |
| `existing` | ❌ | `true` si le tenant existe déjà dans Kestra — Terraform ne le crée pas |

> **Détection automatique** : avant chaque apply, le script interroge l'API Kestra.
> - Tenant **absent** → Terraform le crée
> - Tenant **déjà existant** → Terraform **ne le crée pas** (pas d'erreur 409)
>
> Si la détection automatique échoue (token sans droits sur `/api/v1/tenants`),
> ajoutez `"existing": true` dans le JSON pour forcer le comportement.

---

### `namespaces` — Optionnel

Namespaces à gérer sous ce tenant.

```json
"namespaces": [
  {
    "namespace_id": "dev",                  // ✅ requis
    "description":  "Environnement de dev" // ❌ optionnel
  }
]
```

| Champ | Requis | Description |
|---|---|---|
| `namespace_id` | ✅ | Identifiant du namespace |
| `description` | ❌ | Description affichée dans Kestra |

> **Détection automatique** : le script interroge l'API avant chaque apply.
> - Namespace **absent** → Terraform le crée
> - Namespace **déjà existant** → Terraform **ne le crée pas** (pas d'erreur 409)
>
> Aucun attribut supplémentaire à ajouter dans le JSON pour ce cas.

---

### `roles` — Optionnel

Rôles RBAC à créer. Les rôles sont **toujours gérés par Terraform** — ne déclarez ici que les rôles que Terraform doit posséder.

```json
"roles": [
  {
    "name":        "role-dev",
    "description": "Accès développement",
    "namespace":   "dev",
    "permissions": [
      {
        "type":        "FLOW",
        "permissions": ["READ", "CREATE", "UPDATE", "DELETE"]
      },
      {
        "type":        "EXECUTION",
        "permissions": ["READ", "CREATE"]
      }
    ]
  }
]
```

| Champ | Requis | Description |
|---|---|---|
| `name` | ✅ | Nom du rôle (unique dans le tenant) |
| `description` | ❌ | Description du rôle |
| `namespace` | ❌ | Scope du rôle. Absent ou `null` = rôle global |
| `permissions` | ✅ | Liste des blocs de permissions |
| `permissions[].type` | ✅ | `FLOW`, `EXECUTION`, `NAMESPACE`, `TEMPLATE`, `TRIGGER`, `SECRET` |
| `permissions[].permissions` | ✅ | `READ`, `CREATE`, `UPDATE`, `DELETE` |

---

### `groups` — Optionnel

Groupes **gérés par Terraform** : créés, modifiés et détruits via Terraform.

```json
"groups": [
  {
    "name":        "group-dev",  // ✅ requis
    "description": "...",        // ❌ optionnel
    "namespace":   "dev"         // ❌ optionnel — absent = groupe global
  }
]
```

| Champ | Requis | Description |
|---|---|---|
| `name` | ✅ | Nom du groupe (unique dans le tenant) |
| `description` | ❌ | Description du groupe |
| `namespace` | ❌ | Restreint le groupe à un namespace. Absent = groupe global |

> ⚠️ Si un groupe de cette section existe déjà dans Kestra hors Terraform → erreur **409 Conflict**.
> Dans ce cas, déplacez-le dans `external_groups`.

---

### `external_groups` — Optionnel (cas avancé)

Groupes qui **existent dans Kestra hors Terraform** et que vous voulez référencer dans des `bindings` sans en confier la gestion à Terraform.
Terraform ne les crée **jamais** et ne les détruit **jamais**.

> Dans la majorité des cas, vous n'avez pas besoin de cette section.
> Utilisez `groups` pour tous les groupes que Terraform doit gérer.
> N'utilisez `external_groups` que si un groupe existe dans Kestra et **doit rester hors du périmètre Terraform**.

```json
"external_groups": [
  {
    "name":        "manoamano",  // ✅ requis — nom exact dans Kestra
    "description": "..."         // ❌ optionnel — commentaire libre, non envoyé à l'API
  }
]
```

| Champ | Requis | Description |
|---|---|---|
| `name` | ✅ | Nom exact du groupe tel qu'il existe dans Kestra |
| `description` | ❌ | Commentaire libre (non envoyé à l'API) |

> Si le groupe n'est pas trouvé via l'API au moment du plan, les bindings qui le référencent sont silencieusement ignorés.

---

### `service_accounts` — Optionnel

Service accounts pour l'authentification programmatique (CI/CD, scripts, etc.).

```json
"service_accounts": [
  {
    "name":              "sa-cicd",
    "description":       "Service Account pour la CI/CD",
    "generate_token":    true,
    "token_description": "Token GitHub Actions",
    "token_max_age":     "P180D"
  }
]
```

| Champ | Requis | Description |
|---|---|---|
| `name` | ✅ | Nom du service account |
| `description` | ❌ | Description |
| `generate_token` | ❌ | `true` pour générer un API token (défaut : `false`) |
| `token_description` | ❌ | Description du token généré |
| `token_max_age` | ❌ | Durée de validité au format ISO 8601 (`P90D`, `P1Y`, etc.) |

> ⚠️ Les tokens ne sont visibles **qu'une seule fois** à la création. Copiez-les immédiatement dans Vault.

---

### `bindings` — Optionnel

Associations `groupe → rôle`. Un binding crée un droit d'accès pour un groupe sur un rôle, éventuellement limité à un namespace.

```json
"bindings": [
  {
    "group":     "group-dev",
    "namespace": "dev",
    "roles":     ["role-dev", "role-int"]
  },
  {
    "group": "manoamano",
    "roles": ["role-rec", "role-uat"]
  }
]
```

| Champ | Requis | Description |
|---|---|---|
| `group` | ✅ | Nom du groupe (doit être dans `groups` ou `external_groups`) |
| `roles` | ✅ | Liste des rôles à associer |
| `namespace` | ❌ | Restreint le binding à un namespace |

> Si le groupe ou le rôle référencé n'est pas trouvé (ni dans le JSON ni via l'API), le binding est **silencieusement ignoré**.

---

## 🧠 Tableau de décision — Que fait Terraform selon la situation ?

| Ressource | Déclarée dans JSON | Existe dans Kestra | Action Terraform |
|---|---|---|---|
| Tenant | ✅ | ❌ | Créé |
| Tenant | ✅ | ✅ | Ignoré — détection auto via API ✅ |
| Namespace | ✅ (`namespaces`) | ❌ | Créé |
| Namespace | ✅ (`namespaces`) | ✅ | Ignoré — détection auto via API ✅ |
| Rôle | ✅ (`roles`) | ❌ | Créé |
| Rôle | ✅ (`roles`) | ✅ | ⚠️ 409 Conflict — ne déclarez que les rôles que TF possède |
| Groupe | ✅ (`groups`) | ❌ | Créé |
| Groupe | ✅ (`groups`) | ✅ | ⚠️ 409 Conflict — ce groupe doit aller dans `external_groups` |
| Groupe | ✅ (`external_groups`) | ✅ | UID résolu via API, utilisé dans les bindings ✅ |
| Groupe | ✅ (`external_groups`) | ❌ | Ignoré — bindings associés ignorés aussi ✅ |

---

## 💡 Cas d'usage courants

### Nouveau tenant from scratch

Toutes les ressources sont absentes → Terraform crée tout :

```json
{
  "tenant":     { "tenant_id": "newteam", "label": "New Team" },
  "namespaces": [{ "namespace_id": "dev" }, { "namespace_id": "prod" }],
  "roles":      [{ "name": "developer", "namespace": "dev", "permissions": [...] }],
  "groups":     [{ "name": "team-dev" }],
  "bindings":   [{ "group": "team-dev", "namespace": "dev", "roles": ["developer"] }]
}
```

### Tenant existant — bindings sur un groupe hors Terraform

Le tenant et le groupe existent déjà, on veut juste créer des bindings :

```json
{
  "tenant":          { "tenant_id": "isis", "label": "Isis Tenant" },
  "roles":           [{ "name": "role-audit", "permissions": [...] }],
  "external_groups": [{ "name": "audit-external-team" }],
  "bindings":        [{ "group": "audit-external-team", "roles": ["role-audit"] }]
}
```

### Ajout d'un service account uniquement

```json
{
  "tenant": { "tenant_id": "isis", "label": "Isis Tenant" },
  "service_accounts": [
    {
      "name":           "sa-github",
      "generate_token": true,
      "token_max_age":  "P180D"
    }
  ]
}
```

---

## 📁 Structure du projet

```
gcp/
├── scripts/
│   ├── deploy_tf_module.sh          # Script de déploiement interactif
│   ├── get_kestra_resources.sh      # Découverte des ressources existantes via API Kestra
│   └── isis.sh                      # Variables d'environnement pour l'instance ISIS
└── terraform/
    ├── modules/
    │   └── kmanager/                # Module Terraform générique
    │       ├── main.tf
    │       ├── variables.tf
    │       ├── outputs.tf
    │       ├── provider.tf
    │       └── backend.tf
    └── instanciation/
        └── {plateforme}/{instance}/{tenant}/
            ├── {tenant}.tfvars
            └── jsonconfig/
                └── kestra-config-{tenant_id}.json
```

---

## ⚠️ Bonnes pratiques

- **Ne déclarez dans `groups` que les groupes dont Terraform a la propriété** — si un groupe existe déjà hors Terraform, utilisez `external_groups`
- **Versionnez vos fichiers JSON** dans Git avant chaque déploiement
- **Vérifiez toujours le plan** avant d'appliquer (`plan` est proposé automatiquement par le script)
- **Stockez immédiatement les tokens** dans Vault après génération
- **Évitez les modifications manuelles** sur les ressources gérées par Terraform

---

## 📚 Références

- [Provider Terraform Kestra](https://registry.terraform.io/providers/kestra-io/kestra/latest/docs)
- [Documentation Kestra EE](https://kestra.io/docs)

