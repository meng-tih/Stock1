# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Ces 3 variables forcent la suppression des objets Kestra (bdd et bucket)
# Elles ne doivent être modifiées qu'en cas de suppression
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Permet de detruire le bucket Kestra
force_destroy_bucket = false
# Permet de detruire l'instance cloudsql et ses objets
# false permet de supprimer l'instance clousql
deletion_protection = true
# true permet de supprimer le user et ses objets
allow_user_deletion_with_objects = false

#################################################
# PROJET GCP
#################################################
project_id         = "cagip-kestra-hprd-8b"
project_name       = "cagip-kestra-hprd-8b"
project_short_name = "kestra-hprd"
environment        = "hprd"
region             = "europe-west1"
ptf_name           = "isis"

#################################################
# GKE & BASTION (utilisé par init.sh)
#################################################
zone               = "europe-west1-b"
cluster_name       = ""
cluster_identifier = "kestra"
bastion_name       = ""
bastion_identifier = "bastion"

#################################################
# KESTRA
#################################################
kestra_url         = "http://localhost:8888"

# valeur possible pour kestra_superadmin: "sa" ou "" (vide)
kestra_superadmin  = "sa"

#################################################
# VAULT
#################################################
vault_addr = "https://vault.saas.cagip.group.gca"
vault_secret_path = "cagip/stratus/tradi/prd-intranet/kestra/cagip/kestra-hprd-8b/isis"