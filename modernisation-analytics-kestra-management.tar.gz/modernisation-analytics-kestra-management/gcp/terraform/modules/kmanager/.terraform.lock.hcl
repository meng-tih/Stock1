# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/hashicorp/external" {
  version = "2.4.0"
  hashes = [
    "h1:AmY6ZeIvqoTT5ZjzD+P49PeQH6Va1QLMkX+7MUQfYoA=",
    "zh:0772afb42b658468ac5e15df33bf2080456f8f0b8ab163bfe9c50d2b2ea02135",
    "zh:0ac31a9aaa43dfcff5944b791596cdc94e153348e4bb4642282d034dff548134",
    "zh:32d8492b1bdcc956ca3c6d00c6392d0a83942ff11d4820c7ee63ca6796e06950",
    "zh:3c0482e894429f528ce6655a76ab0d8a9f7c0dacc6c828865e1515d4a7dbb852",
    "zh:61e68100b4db2f930b31491f23c602126382fd5e51252be1b551f0e17f8ddbee",
    "zh:6d60f615a0ad85eb962c9eb94f25e3eba7a72684ce276ba5dfb23f36b295a8f8",
    "zh:78d5eefdd9e494defcb3c68d282b8f96630502cac21d1ea161f53cfe9bb483b3",
    "zh:9ced2745eb5f1346203027d2dd7bf856ad1d279a25730ff7dbc6eec187aaca0c",
    "zh:a8378558a177d43f55aa0d79d4fae91a704695122a1b109668c1daa8fb76f09d",
    "zh:aadd98086133d3ebea67437d56512fdcc6dfb3bd34dfc23f276c0db9272e27b4",
    "zh:beff701b653841e70441978137768f54e7dc6c27e7bf12a4589087f01f5bbcee",
    "zh:c91c2223b29fdbc0044d20e1936ccc051d010727a13f2ff1e75e51f09bff33a3",
    "zh:d491f9c2d32a39dc4031628469ae7c8aec0074312a7c1f0286b173cdcf854a54",
  ]
}

provider "registry.terraform.io/hashicorp/google" {
  version     = "7.32.0"
  constraints = "~> 7.16"
  hashes = [
    "h1:hDMENgq6nxoM6ttxN1HNrqbYiyRV8avLmUuUe4QWvKY=",
    "zh:091afeeeb58035f26ebaec34755a15d56e3229c4ce6db2745c52ba2593204a30",
    "zh:15d6a375c49d023dd21e612610b12bf79fbc6459bc5ad64b989d2180e9931f7d",
    "zh:2c70ee949b01c0c7925618e36417ac5b9c1de91c66bb0bd956b2b2bd1d38a2b6",
    "zh:2e531cf6f3af847104df65675ebd9c9a7450ba91d8d21ff6ed04eeab6a5684e2",
    "zh:42fece780ef909136213762731c945d59c58dbaf92f64a46989102da9ebfa998",
    "zh:9008b13bec8c588ef41ec813c3d67d26acb22ada241d9dd9ed408687607726cc",
    "zh:a62e09bd551de8ea74b68c1eb44f9d7d0dc56957811915d46ec0a28254a30e0b",
    "zh:ad3d4419561d19e88b72ad4bedbbc73ee77f20acb594261be8f716bf1a89f947",
    "zh:af0c23df89e5fb815751c64c9a438527d6e0609df52fa7e281dbd90aa238270b",
    "zh:b4d1157559d04792441550ae79f13d16bd7cc3f80a9616cd9ef3f83466564ce4",
    "zh:db32528838dc9641981769012bdabf21e658756f1581ccbcd239aab0eb4aed11",
    "zh:f569b65999264a9416862bca5cd2a6177d94ccb0424f3a4ef424428912b9cb3c",
  ]
}

provider "registry.terraform.io/hashicorp/vault" {
  version     = "3.25.0"
  constraints = "~> 3.0"
  hashes = [
    "h1:3GN5k6zxDAI5gfcKENb/jnJyFGWA/0JoumnD6eyVZjs=",
    "zh:430308f5dbd322a2e5afafd2be810f44eb35e28afa0aa0ac30b270cd6f413da8",
    "zh:6c36da504c4af84ea9fbaf1e6c2560f691dc3d2d7f0b382a937bfae78830fa17",
    "zh:78d5eefdd9e494defcb3c68d282b8f96630502cac21d1ea161f53cfe9bb483b3",
    "zh:7bc39cb2a7d91631cb8be54b0b06de29fb47910923e54f779e74d8b218b1ab70",
    "zh:7e4a5bebcfa19b9f1e3a6bbda5c6771b6dd28b3dfa19fdf3d4fced419cfa416f",
    "zh:7ea473203b37d006a0d2b1cdc8bff55c96b3c5819dbb62862cdabff6f2f0e2f2",
    "zh:9ad136feece62f0c545fefa4592b2cdaa896a39acb697fb129233dce880a69aa",
    "zh:ad0c9980295c902804af23da0250830b912eb13089349bf5c7be0649fac2689c",
    "zh:b305835cc13dcd9ec996d49d23163c6311f30786296f86ca5657b93aea4f3591",
    "zh:d8fe6ab7da12efbb5b122ae9b6856375c5a3759add9df577a8fb448898ceffe3",
    "zh:ef59ef2c06a55571e64fdd5888a074ed9556436738e9737e32bacab93ca133ff",
    "zh:f59c2605d916e1806dc494241467dd430194f5e7bdbf331c5aca904873347ad8",
  ]
}

provider "registry.terraform.io/kestra-io/kestra" {
  version     = "1.0.2"
  constraints = "~> 1.0.2"
  hashes = [
    "h1:rWpUEPnQd5siWDQWS6aJxYty4dpsXFf1K73UC2AJf7M=",
    "zh:0dd0cc281fb35c6974d0ecd5641df9931ea275c2138e291eab91da26a0c15539",
    "zh:360c8c7c162fbfe322dd8bd18d30363a21a43e065dd05cc6bb0eac9cc646ba06",
    "zh:36ed8e53471ff0bcc9465ad9d2f510987dedc184e1ce2af525174f88715ffe41",
    "zh:3a5cec7cd4e3ead4bccca0843d42941ae820bbe5406f0f12caf6f89cc1628f39",
    "zh:578308460c48903f4118577895e28a2f83083c27137f40bd0a460a71ba419c50",
    "zh:5d8b97d2ec182bbdbf4f8db55d00dac350bc8a70043b31ebb0662aa323c5a871",
    "zh:65765d142033c77f7d1d711800beb322cc71553f82b1c5fddb3e5361e3916a82",
    "zh:809d9b0504f2d301d917fae27db50420f24f6fac319a4222fcf8f05c820e0ed6",
    "zh:8761ba6415e71bac20394eb3b607444b315aee1008de7ef2947fa7905718bec3",
    "zh:8c0fba257bd2eb1db805f883d720048119f76a57e0f892efe23cf2855c357c52",
    "zh:b3a8700e2afce220678ab0080fb1ca6e3d60f1137ffbd7a6bfe9d4737c76982a",
    "zh:cd9a9c8497fcc85de9f0cb4e922d706cb97788f2f35087326d95c78db9680f67",
    "zh:d57dbc624e89ab320f5ac9d16146e0a7483372f18e1b542f7a87b89ca6aa304d",
    "zh:dbc5f443ffc6e589ebeeb0e666363a99b3f1496c779eed0e27f54be402223490",
  ]
}
