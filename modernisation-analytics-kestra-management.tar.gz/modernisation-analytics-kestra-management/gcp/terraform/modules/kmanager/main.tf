# =============================================================================
# RÉCUPÉRATION DES SECRETS DEPUIS VAULT
# =============================================================================
# Récupère les credentials Kestra Manager depuis Vault via AppRole authentication.
# Ces credentials sont utilisés par le provider Kestra pour s'authentifier.
# Sécurité: Les valeurs sont marquées comme sensibles dans le provider.
data "vault_kv_secret_v2" "km_credentials" {
  mount = "secret"
  name  = var.vault_secret_path
}

# tenant_id isolé ici pour être disponible dans les data "external" sans dépendance circulaire.
locals {
  _config    = jsondecode(file(var.config_file_path))
  tenant_id  = try(local._config.tenant.tenant_id, null)
  has_tenant = try(local._config.tenant, null) != null
  # "existing": true dans le JSON = tenant déclaré comme déjà existant dans Kestra.
  # Utilisé comme fallback si la détection API échoue (token sans droits sur /tenants, etc.).
  tenant_existing_hint = try(local._config.tenant.existing, false)
}

# =============================================================================
# RÉSOLUTION DES RESSOURCES KESTRA EXISTANTES (via API)
# =============================================================================
# Appelle get_kestra_resources.sh pour récupérer les UIDs des ressources qui
# existent déjà dans Kestra (créées hors Terraform ou lors d'un apply précédent).
# 3 appels séparés car data "external" exige un JSON à plat en sortie.
# ⚠️ SÉCURITÉ : le token est sensible (jamais loggué par Terraform).
# Vérifie si le tenant existe déjà dans Kestra avant de tenter la création.
# Retourne { "exists": "true" | "false" }.
data "external" "kestra_existing_tenant" {
  count   = local.has_tenant ? 1 : 0
  program = ["${path.module}/../../../scripts/get_kestra_resources.sh"]
  query = {
    kestra_url   = var.kestra_url
    token        = sensitive(data.vault_kv_secret_v2.km_credentials.data["KESTRA_TOKEN_KM"])
    tenant_id    = local.tenant_id
    resource     = "tenant"
    superadmin   = var.kestra_superadmin
  }
  depends_on = [data.vault_kv_secret_v2.km_credentials]
}

data "external" "kestra_existing_namespaces" {
  program = ["${path.module}/../../../scripts/get_kestra_resources.sh"]
  query = {
    kestra_url = var.kestra_url
    token      = sensitive(data.vault_kv_secret_v2.km_credentials.data["KESTRA_TOKEN_KM"])
    tenant_id  = local.tenant_id
    resource   = "namespaces"
  }
  depends_on = [data.vault_kv_secret_v2.km_credentials]
}

data "external" "kestra_existing_roles" {
  program = ["${path.module}/../../../scripts/get_kestra_resources.sh"]
  query = {
    kestra_url = var.kestra_url
    token      = sensitive(data.vault_kv_secret_v2.km_credentials.data["KESTRA_TOKEN_KM"])
    tenant_id  = local.tenant_id
    resource   = "roles"
  }
  depends_on = [data.vault_kv_secret_v2.km_credentials]
}

data "external" "kestra_existing_groups" {
  program = ["${path.module}/../../../scripts/get_kestra_resources.sh"]
  query = {
    kestra_url = var.kestra_url
    token      = sensitive(data.vault_kv_secret_v2.km_credentials.data["KESTRA_TOKEN_KM"])
    tenant_id  = local.tenant_id
    resource   = "groups"
  }
  depends_on = [data.vault_kv_secret_v2.km_credentials]
}

data "external" "kestra_existing_service_accounts" {
  program = ["${path.module}/../../../scripts/get_kestra_resources.sh"]
  query = {
    kestra_url = var.kestra_url
    token      = sensitive(data.vault_kv_secret_v2.km_credentials.data["KESTRA_TOKEN_KM"])
    tenant_id  = local.tenant_id
    resource   = "service_accounts"
  }
  depends_on = [data.vault_kv_secret_v2.km_credentials]
}

# =============================================================================
# CONFIGURATION LOCALE
# =============================================================================
locals {
  config = local._config

  # Tenant déjà existant si :
  #   - le script détecte "exists": "true" via l'API
  #   - OU "existing": true est déclaré explicitement dans le JSON (fallback)
  tenant_already_exists = local.tenant_existing_hint || (
    local.has_tenant && length(data.external.kestra_existing_tenant) > 0
    ? data.external.kestra_existing_tenant[0].result["exists"] == "true"
    : false
  )
  has_namespaces       = try(length(local.config.namespaces), 0) > 0
  has_roles            = try(length(local.config.roles), 0) > 0
  has_groups           = try(length(local.config.groups), 0) > 0
  has_external_groups  = try(length(local.config.external_groups), 0) > 0
  has_service_accounts = try(length(local.config.service_accounts), 0) > 0
  has_bindings         = try(length(local.config.bindings), 0) > 0

  # Maps { "nom" => "uid" } des ressources déjà présentes dans Kestra (via API).
  # Utilisés UNIQUEMENT pour résoudre les UIDs dans les bindings (external_groups, etc.).
  # ⚠️ Ne pas utiliser pour filtrer les ressources gérées par TF.
  existing_namespace_uids = data.external.kestra_existing_namespaces.result
  existing_role_uids      = data.external.kestra_existing_roles.result
  existing_group_uids     = data.external.kestra_existing_groups.result
  existing_service_account_uids = data.external.kestra_existing_service_accounts.result
  # Noms des groupes externes déclarés dans le JSON (créés hors TF, jamais touchés par TF).
  # Leur UID est résolu via data "external" (existing_group_uids).
  external_group_names = local.has_external_groups ? [
    for g in local.config.external_groups : g.name
  ] : []
}

# =============================================================================
# 1. TENANT (OPTIONNEL)
# =============================================================================
# Crée un tenant Kestra si défini dans la configuration.
# Le tenant isole logiquement les ressources dans une instance Kestra multi-tenant.
# Utilise count pour création conditionnelle (0 ou 1).
resource "kestra_tenant" "tenant" {
  # count = 0 si "existing": true dans le JSON (tenant hors TF)
  # count = 0 si pas de section tenant dans le JSON
  # count = 1 si tenant déclaré sans "existing": true → TF le crée et le gère
  # ⚠️ On n'utilise PAS tenant_already_exists (détection API) ici :
  #   après le 1er apply, l'API retourne le tenant → count passerait à 0 → destroy.
  count = local.has_tenant && !local.tenant_existing_hint ? 1 : 0

  tenant_id = local.config.tenant.tenant_id
  name      = try(local.config.tenant.label, local.config.tenant.description, null)
}

# =============================================================================
# 2. NAMESPACES (OPTIONNEL)
# =============================================================================
# Crée les namespaces Kestra définis dans la configuration.
# Les namespaces organisent les workflows et ressources dans Kestra.
# Dépend du tenant si celui-ci est créé.
resource "kestra_namespace" "namespaces" {
  # TF gère tous les namespaces déclarés dans le JSON (crée, modifie, détruit).
  # Pas de filtre API : après le 1er apply, l'API les retournerait → ils sortiraient
  # du for_each → destroy. Le script sert uniquement à résoudre les UIDs pour les bindings.
  for_each = local.has_namespaces ? {
    for ns in local.config.namespaces : ns.namespace_id => ns
  } : {}

  namespace_id = each.value.namespace_id
  description  = try(each.value.description, null)

  depends_on = [kestra_tenant.tenant]
}

# =============================================================================
# 3. RÔLES (OPTIONNEL)
# =============================================================================
# Crée les rôles RBAC avec leurs permissions associées.
# Chaque rôle peut avoir plusieurs blocs de permissions (type: FLOW, EXECUTION, etc.).
# Les rôles peuvent être globaux (namespace=null) ou limités à un namespace.
resource "kestra_role" "roles" {
  for_each = local.has_roles ? {
    for role in local.config.roles : role.name => role
  } : {}

  name        = each.value.name
  description = try(each.value.description, null)
  namespace   = try(each.value.namespace, null)

  dynamic "permissions" {
    for_each = try(each.value.permissions, [])
    content {
      type        = permissions.value.type
      permissions = permissions.value.permissions
    }
  }

  depends_on = [kestra_namespace.namespaces]
}

# =============================================================================
# 4. GROUPES (OPTIONNEL)
# =============================================================================
# Crée les groupes d'utilisateurs pour le RBAC.
# Les groupes seront liés aux rôles via les bindings (section 6).
# Peuvent être globaux ou limités à un namespace spécifique.
#
# ⚠️ Filtre : les groupes avec un champ "uid" dans le JSON sont exclus de la
# création — ils existent déjà dans Kestra (créés hors Terraform).
# Leur UID est utilisé directement dans les bindings via local.preset_group_uids.
resource "kestra_group" "groups" {
  for_each = local.has_groups ? {
    for group in local.config.groups : group.name => group
  } : {}

  name        = each.value.name
  description = try(each.value.description, null)
  namespace   = try(each.value.namespace, null)

  depends_on = [kestra_namespace.namespaces]
}

# =============================================================================
# 5. SERVICE ACCOUNTS (OPTIONNEL)
# =============================================================================
# Crée les service accounts pour l'authentification programmatique.
# Ces comptes permettent aux applications/scripts d'interagir avec l'API Kestra.
# Peuvent générer des API tokens (voir section 5.1).
resource "kestra_service_account" "service_accounts" {
  for_each = local.has_service_accounts ? { for sa in local.config.service_accounts : sa.name => sa } : {}

  name        = each.value.name
  description = try(each.value.description, null)

  # Rattache le SA aux groupes déclarés dans le JSON (champ "groups" : liste de noms).
  # Le SA hérite ainsi des bindings groupe→rôle et dispose des droits correspondants.
  dynamic "groups" {
    for_each = [
      for g in try(each.value.groups, []) : g
      if contains(local.created_groups, g)
    ]
    content {
      id = kestra_group.groups[groups.value].id
    }
  }

  depends_on = [kestra_group.groups]
}

# =============================================================================
# 5.1. API TOKENS POUR SERVICE ACCOUNTS (OPTIONNEL)
# =============================================================================
# Génère des API tokens pour les service accounts qui en ont besoin.
# ⚠️ SÉCURITÉ: Les tokens sont visibles UNE SEULE FOIS à la création.
# Ils doivent être immédiatement stockés dans un gestionnaire de secrets (Vault).
# Filtre: seuls les SA avec generate_token=true obtiennent un token.
resource "kestra_service_account_api_token" "sa_tokens" {
  for_each = local.has_service_accounts ? { for sa in local.config.service_accounts : sa.name => sa if try(sa.generate_token, false) } : {}

  name               = "${each.value.name}-token"
  description        = try(each.value.token_description, "API Token for ${each.value.name}")
  service_account_id = kestra_service_account.service_accounts[each.key].id
  max_age            = try(each.value.token_max_age, null)

  depends_on = [kestra_service_account.service_accounts]
}

# =============================================================================
# 6. BINDINGS GROUPE-RÔLE (OPTIONNEL)
# =============================================================================
# Crée les associations entre groupes et rôles (RBAC).
# Processus: transforme la config JSON en liste plate de bindings individuels.
# Chaque binding associe 1 groupe à 1 rôle (relation many-to-many gérée ici).
# ⚠️ SÉCURITÉ: Validation des références pour éviter les erreurs d'exécution.
locals {
  # Groupes et rôles déclarés dans le JSON (gérés par Terraform)
  created_groups = local.has_groups ? [for group in local.config.groups : group.name] : []
  created_roles  = local.has_roles ? [for role in local.config.roles : role.name] : []
  # Namespaces effectivement créés par TF (absents de l'API au moment du plan)
  created_namespaces = local.has_namespaces ? [
    for ns in local.config.namespaces : ns.namespace_id
    if !contains(keys(local.existing_namespace_uids), ns.namespace_id)
  ] : []

  # Union : groupes TF + groupes externes dont l'UID est effectivement résolu via API
  # On exclut les external_groups dont l'UID n'est pas disponible (script a retourné {})
  resolved_external_group_names = [for name in local.external_group_names : name if contains(keys(local.existing_group_uids), name)]
  all_known_roles  = distinct(concat(local.created_roles, keys(local.existing_role_uids)))
  all_known_groups = distinct(concat(local.created_groups, local.resolved_external_group_names))
  # Creation d'une liste locale de bindings individuels (1 groupe - 1 rôle) à partir de la config JSON.
  # le but ici c'est de pouvoir filtrer sur les bindings group uniquement
  group_bindings = [
    for binding in try(local.config.bindings, []) : {
      group     = binding.group
      roles     = [for role_name in try(binding.roles, []) : tostring(role_name)]
      namespace = try(binding.namespace, null)
    }
    if try(binding.group, null) != null
  ]
    
  #lit uniquement les bindings groupe pré-filtrés.
  binding_list = flatten([
    for binding in local.group_bindings : [
       #  crée 1 binding par rôle.
      for role_name in binding.roles : {
        key        = "${binding.group}-${role_name}"
        group_name = binding.group
        role_name  = role_name
        namespace  = try(binding.namespace, null)
    #garde seulement si groupe et rôle sont connus.
      } if contains(local.all_known_groups, binding.group) && contains(local.all_known_roles, role_name)
    ]
  ])

  # Validation : bindings avec références invalides (pour debug)
  invalid_bindings = flatten([
    for binding in local.group_bindings : [
      for role_name in binding.roles : {
        group = binding.group
        role  = role_name
        issue = !contains(local.all_known_groups, binding.group) ? "groupe inconnu (absent du JSON ou sans uid)" : "rôle inconnu (absent du JSON ou sans uid)"
      } if !contains(local.all_known_groups, binding.group) || !contains(local.all_known_roles, role_name)
    ]
  ])
}

resource "kestra_binding" "bindings" {
  for_each = { for b in local.binding_list : b.key => b }

  namespace = each.value.namespace
  type      = "GROUP" # Type fixe: liaison groupe-rôle

  # Résolution de l'UID du rôle :
  #   - Rôle déclaré dans le JSON → géré par TF → on prend kestra_role.roles[].id
  #   - Rôle hors JSON (découvert via API uniquement) → on prend l'UID API
  role_id = contains(local.created_roles, each.value.role_name) ? kestra_role.roles[each.value.role_name].id : local.existing_role_uids[each.value.role_name]

  # Groupe déclaré dans groups (géré TF) → kestra_group.groups[].id
  # Groupe déclaré dans external_groups (hors TF) → UID découvert via API
  external_id = contains(local.created_groups, each.value.group_name) ? kestra_group.groups[each.value.group_name].id : local.existing_group_uids[each.value.group_name]

  depends_on = [kestra_role.roles, kestra_group.groups]
}


# =============================================================================
# 7. BINDINGS SERVICE ACCOUNT-RÔLE (OPTIONNEL)
# =============================================================================
# Crée les associations entre service accounts et rôles (RBAC).
# Même logique que les bindings groupe-rôle (section 6) mais type = "SERVICE_ACCOUNT".
# ⚠️ SÉCURITÉ: Validation des références pour éviter les erreurs d'exécution.
locals {
  service_account_bindings = [
    for binding in try(local.config.bindings, []) : {
      service_account = binding.service_account
      roles           = [for role_name in try(binding.roles, []) : tostring(role_name)]
      namespace       = try(binding.namespace, null)
    }
    if try(binding.service_account, null) != null
  ]

  has_sa_bindings = length(local.service_account_bindings) > 0

  # SA déclarés dans le JSON (gérés par TF)
  created_service_accounts = local.has_service_accounts ? [
    for sa in local.config.service_accounts : sa.name
  ] : []

  sa_binding_list = local.has_sa_bindings ? flatten([
    for b in local.service_account_bindings : [
      for role_name in b.roles : {
        key       = "${b.service_account}-${role_name}"
        sa_name   = b.service_account
        role_name = role_name
        namespace = try(b.namespace, null)
      }
      # Validation : le SA et le rôle doivent être connus
      if contains(local.created_service_accounts, b.service_account)
      && contains(local.all_known_roles, role_name)
    ]
  ]) : []

  # Bindings invalides pour debug
  invalid_sa_bindings = local.has_sa_bindings ? flatten([
    for b in local.service_account_bindings : [
      for role_name in b.roles : {
        service_account = b.service_account
        role            = role_name
        issue = !contains(local.created_service_accounts, b.service_account) ? "service account inconnu (absent du JSON)" : "rôle inconnu (absent du JSON ou sans uid)"
      }
      if !contains(local.created_service_accounts, b.service_account)
      || !contains(local.all_known_roles, role_name)
    ]
  ]) : []
}

resource "kestra_binding" "sa_bindings" {
  for_each = { for b in local.sa_binding_list : b.key => b }

  namespace = each.value.namespace
  type      = "USER"

  # Résolution de l'UID du rôle (même logique que section 6)
  role_id = contains(local.created_roles, each.value.role_name) ? kestra_role.roles[each.value.role_name].id : local.existing_role_uids[each.value.role_name]

  # UID du service account géré par TF
  external_id = kestra_service_account.service_accounts[each.value.sa_name].id

  depends_on = [kestra_role.roles, kestra_service_account.service_accounts]
}