# =============================================================================
# OUTPUTS - IDENTIFIANTS DES RESSOURCES
# =============================================================================
# Ces outputs exposent les IDs des ressources créées pour utilisation en aval.
# ⚠️ Les outputs sensibles (tokens) sont marqués avec sensitive = true.

output "tenant_id" {
  description = "ID du tenant créé (si créé)"
  value       = length(kestra_tenant.tenant) > 0 ? kestra_tenant.tenant[0].tenant_id : null
}

output "namespace_ids" {
  description = "IDs des namespaces (créés par TF + pré-existants via API)"
  value = merge(
    { for k, v in kestra_namespace.namespaces : k => v.namespace_id },
    local.existing_namespace_uids
  )
}

output "role_ids" {
  description = "Map des rôles (nom -> UUID) — créés par TF + pré-existants via API"
  value = merge(
    { for k, v in kestra_role.roles : k => v.id },
    local.existing_role_uids
  )
}

output "group_ids" {
  description = "Map des groupes (nom -> UUID) — créés par TF + pré-existants via API"
  value = merge(
    { for k, v in kestra_group.groups : k => v.id },
    local.existing_group_uids
  )
}

output "service_account_ids" {
  description = "Map des service accounts (nom -> UUID)"
  value       = { for k, v in kestra_service_account.service_accounts : k => v.id }
}

# =============================================================================
# OUTPUTS SENSIBLES - API TOKENS
# =============================================================================
# 🔒 SÉCURITÉ: Ces outputs contiennent des tokens d'API sensibles.
# - Marqués comme sensitive = true (masqués dans les logs Terraform)
# - Utilisez: terraform output service_account_tokens pour afficher
# - ⚠️ Stockez IMMÉDIATEMENT dans Vault après création
# - Les tokens ne sont visibles qu'UNE SEULE FOIS à la création

output "service_account_tokens" {
  description = "⚠️ TOKENS API (utiliser: terraform output service_account_tokens)"
  value = {
    for k, v in kestra_service_account_api_token.sa_tokens : k => {
      token_id        = v.id
      token_value     = v.full_token
      service_account = v.service_account_id
      description     = v.name
      max_age         = v.max_age
    }
  }
  sensitive = true
}

output "binding_ids" {
  description = "IDs des bindings créés"
  value       = [for b in kestra_binding.bindings : b.id]
}

output "invalid_bindings" {
  description = "⚠️ Bindings avec références invalides (non créés)"
  value = length(local.invalid_bindings) > 0 ? {
    count   = length(local.invalid_bindings)
    details = local.invalid_bindings
  } : null
}

# =============================================================================
# OUTPUT RÉSUMÉ
# =============================================================================
# Vue d'ensemble des ressources déployées (compteurs uniquement).

output "summary" {
  description = "Résumé de la configuration déployée"
  value = {
    tenant           = length(kestra_tenant.tenant) > 0 ? kestra_tenant.tenant[0].tenant_id : "none"
    namespaces       = length(kestra_namespace.namespaces)
    roles            = length(kestra_role.roles)
    groups           = length(kestra_group.groups)
    service_accounts = length(kestra_service_account.service_accounts)
    api_tokens       = length(kestra_service_account_api_token.sa_tokens)
    bindings         = length(kestra_binding.bindings)
  }
}

output "tokens_details" {
  description = "📋 DÉTAILS COMPLETS DES TOKENS API (utiliser: terraform output -raw tokens_details)"
  sensitive   = true
  value = length(kestra_service_account_api_token.sa_tokens) > 0 ? join("\n", [
    "",
    "════════════════════════════════════════════════════════════════",
    "🔑 TOKENS API DES SERVICE ACCOUNTS - TENANT: ${length(kestra_tenant.tenant) > 0 ? kestra_tenant.tenant[0].tenant_id : "N/A"}",
    "════════════════════════════════════════════════════════════════",
    "",
    "⚠️  IMPORTANT: Ces tokens ne seront visibles qu'une seule fois!",
    "📝 Copiez-les immédiatement et stockez-les en lieu sûr (Vault, etc.)",
    "",
    join("\n", [for k, v in kestra_service_account_api_token.sa_tokens : join("\n", [
      "-----------------------------------------------------------",
      "Service Account: ${k}",
      "Token ID:        ${v.id}",
      "Description:     ${v.name}",
      "Max Age:         ${v.max_age}",
      "",
      "🔐 TOKEN VALUE (à copier):",
      v.full_token,
      "-----------------------------------------------------------"
    ])]),
    "",
    "════════════════════════════════════════════════════════════════",
    "",
    "💡 Pour stocker dans Vault:",
    "vault kv put <path> ${join(" ", [for k, v in kestra_service_account_api_token.sa_tokens : "${k}='${v.full_token}'"])}",
    ""
  ]) : "Aucun token API généré"
}
