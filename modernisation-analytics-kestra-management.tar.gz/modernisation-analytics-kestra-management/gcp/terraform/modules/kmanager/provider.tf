terraform {
  required_version = ">= 1.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 7.16"
    }
    kestra = {
      source  = "kestra-io/kestra"
      version = "~> 1.0.2"
    }
    vault = {
      source  = "hashicorp/vault"
      version = "~> 3.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

provider "kestra" {
  url       = var.kestra_url
  api_token = data.vault_kv_secret_v2.km_credentials.data["KESTRA_TOKEN_KM"]
  tenant_id = local.tenant_id
}

provider "vault" {
  address = var.vault_addr

  skip_child_token = true

  auth_login {
    path = "auth/approle/login"

    parameters = {
      role_id   = var.vault_role_id
      secret_id = var.vault_secret_id
    }
  }
}
