variable "project_id" {
  type        = string
  description = "ID du projet GCP"
}

variable "region" {
  type        = string
  description = "Région GCP"
}

variable "ptf_name" {
  type        = string
  description = "Nom de la plateforme"
}

variable "kestra_url" {
  description = "URL de l'instance Kestra"
  type        = string

  validation {
    condition     = can(regex("^https?://", var.kestra_url))
    error_message = "L'URL Kestra doit commencer par http:// ou https://."
  }
}

variable "kestra_superadmin" {
  description = "Indique si le token Kestra est super-admin. Mettre 'sa' si super-admin (accès /api/v1/tenants), laisser vide sinon."
  type        = string
  default     = ""
}

variable "config_file_path" {
  description = "Chemin du fichier JSON de configuration unifié"
  type        = string

  validation {
    condition     = can(regex("\\.json$", var.config_file_path))
    error_message = "Le fichier de configuration doit avoir l'extension .json."
  }
}

# Variables Vault
variable "vault_addr" {
  description = "URL du serveur Vault"
  type        = string

  validation {
    condition     = can(regex("^https?://", var.vault_addr))
    error_message = "L'URL Vault doit commencer par http:// ou https://."
  }
}

variable "vault_role_id" {
  description = "AppRole Role ID pour l'authentification Vault"
  type        = string
  sensitive   = true
}

variable "vault_secret_id" {
  description = "AppRole Secret ID pour l'authentification Vault"
  type        = string
  sensitive   = true
}

variable "vault_secret_path" {
  description = "Chemin du secret dans Vault"
  type        = string

  validation {
    condition     = length(var.vault_secret_path) > 0
    error_message = "Le chemin du secret Vault ne peut pas être vide."
  }
}
