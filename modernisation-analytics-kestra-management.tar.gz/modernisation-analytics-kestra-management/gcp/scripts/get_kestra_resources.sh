#!/usr/bin/env bash
# =============================================================================
# get_kestra_resources.sh
# =============================================================================
# Récupère les UIDs des ressources Kestra existantes via l'API REST.
#
# --- Mode interactif ---
# Usage : ./get_kestra_resources.sh <URL> <TOKEN> <TENANT_ID> [OUTPUT_FILE]
# Affiche namespaces, roles, groupes + génère un fichier JSON de référence.
#
# --- Mode Terraform data "external" ---
# Appelé sans argument, lit un JSON depuis stdin :
#   { "kestra_url": "...", "token": "...", "tenant_id": "...", "resource": "..." }
# "resource" peut valoir : "namespaces" | "roles" | "groups"
# Retourne un JSON à plat sur stdout : { "nom": "uid", ... }
# =============================================================================
set -euo pipefail

# =============================================================================
# Fonction : appel API Kestra + vérification
# =============================================================================
kestra_api() {
  local url="$1"
  local response
  response=$(curl -s -H "Authorization: Bearer ${TOKEN}" "${url}")

  if ! echo "$response" | jq empty 2>/dev/null; then
    echo "❌ Réponse API invalide : ${url}" >&2
    exit 1
  fi

  local msg
  msg=$(echo "$response" | jq -r '.message // empty')
  if [[ "$msg" == "Unauthorized" ]]; then
    echo "❌ Erreur 401 : token invalide ou expiré" >&2
    exit 1
  fi

  echo "$response"
}

# =============================================================================
# MODE TERRAFORM data "external" : stdin JSON → stdout JSON à plat
# =============================================================================
if [[ $# -eq 0 ]]; then
  INPUT=$(cat)
  KESTRA_URL=$(echo "$INPUT" | jq -r '.kestra_url')
  TOKEN=$(echo "$INPUT"      | jq -r '.token')
  TENANT_ID=$(echo "$INPUT"  | jq -r '.tenant_id')
  RESOURCE=$(echo "$INPUT"   | jq -r '.resource')

  BASE="${KESTRA_URL}/api/v1/${TENANT_ID}"

  # Test de connectivité : si le tenant n'existe pas encore (404/401),
  # ou si le token n'a pas les droits (Unauthorized dans le body),
  # on retourne {} sans erreur pour ne pas bloquer le premier apply.
  PROBE_BODY=$(curl -s \
    -H "Authorization: Bearer ${TOKEN}" \
    "${BASE}/groups/search")
  PROBE_MSG=$(echo "$PROBE_BODY" | jq -r '.message // empty' 2>/dev/null || true)

  if ! echo "$PROBE_BODY" | jq empty 2>/dev/null || [[ "$PROBE_MSG" == "Unauthorized" ]] || [[ -z "$PROBE_BODY" ]]; then
    echo "⚠️  Tenant '${TENANT_ID}' inaccessible (${PROBE_MSG:-réponse invalide}) — aucune ressource existante détectée." >&2
    echo "{}"
    exit 0
  fi

  # Fonction interne pour appel API en mode Terraform (renvoie {} au lieu d'exit 1)
  tf_kestra_api() {
    local url="$1"
    local resp
    resp=$(curl -s -H "Authorization: Bearer ${TOKEN}" "${url}")
    local msg
    msg=$(echo "$resp" | jq -r '.message // empty' 2>/dev/null || true)
    if ! echo "$resp" | jq empty 2>/dev/null || [[ "$msg" == "Unauthorized" ]]; then
      echo "⚠️  Erreur API ${url} (${msg:-réponse invalide})" >&2
      echo "{}"
      return 0
    fi
    echo "$resp"
  }

  # Extraction sécurisée : si tf_kestra_api renvoie {}, on court-circuite le jq
  safe_extract() {
    local raw="$1"
    local jq_filter="$2"
    if [[ "$raw" == "{}" ]] || [[ -z "$raw" ]]; then
      echo "{}"
    else
      echo "$raw" | jq "$jq_filter"
    fi
  }

  case "$RESOURCE" in
    tenant)
      # Vérifie si le tenant existe déjà dans Kestra.
      # Seulement si superadmin="sa" (token avec accès /api/v1/tenants).
      # Sinon retourne {"exists": "false"} — le JSON "existing": true prend le relais.
      SUPERADMIN=$(echo "$INPUT" | jq -r '.superadmin // empty')
      if [[ "$SUPERADMIN" == "sa" ]]; then
        TENANT_RESP=$(curl -s -o /dev/null -w "%{http_code}" \
          -H "Authorization: Bearer ${TOKEN}" \
          "${KESTRA_URL}/api/v1/tenants/${TENANT_ID}")
        if [[ "$TENANT_RESP" == "200" ]]; then
          echo '{"exists": "true"}'
        else
          echo '{"exists": "false"}'
        fi
      else
        # Pas super-admin : on ne peut pas interroger /api/v1/tenants → retour false
        # Utiliser "existing": true dans le JSON pour signaler un tenant déjà existant.
        echo '{"exists": "false"}'
      fi
      ;;
    namespaces)
      RAW=$(tf_kestra_api "${BASE}/namespaces/search")
      safe_extract "$RAW" '[.results[] | {key: .id, value: .id}] | from_entries'
      ;;
    roles)
      RAW=$(tf_kestra_api "${BASE}/roles/search")
      safe_extract "$RAW" '[.results[] | {key: .name, value: .id}] | from_entries'
      ;;
    groups)
      RAW=$(tf_kestra_api "${BASE}/groups/search")
      safe_extract "$RAW" '[.results[] | {key: .name, value: .id}] | from_entries'
      ;;
    service_accounts)
      RAW=$(tf_kestra_api "${BASE}/service-accounts")
      safe_extract "$RAW" '[.results[] | {key: .name, value: .id}] | from_entries'
      ;;
    *)
      echo "❌ resource inconnu : ${RESOURCE} (valeurs : namespaces | roles | groups | service_accounts)" >&2
      exit 1
      ;;
  esac
  exit 0
fi

# =============================================================================
# MODE INTERACTIF : arguments positionnels
# =============================================================================
KESTRA_URL="${1:?Usage: $0 <KESTRA_URL> <API_TOKEN> <TENANT_ID> [OUTPUT_FILE]}"
TOKEN="${2:?Usage: $0 <KESTRA_URL> <API_TOKEN> <TENANT_ID> [OUTPUT_FILE]}"
TENANT_ID="${3:?Usage: $0 <KESTRA_URL> <API_TOKEN> <TENANT_ID> [OUTPUT_FILE]}"
OUTPUT_FILE="${4:-resources_${TENANT_ID}.json}"
BASE="${KESTRA_URL}/api/v1/${TENANT_ID}"

[[ -f "$OUTPUT_FILE" ]] && rm -f "$OUTPUT_FILE" && echo "🗑️  Fichier existant supprimé : ${OUTPUT_FILE}"

echo ""
echo "════════════════════════════════════════════"
echo "  🔍 Kestra Resources — tenant : ${TENANT_ID}"
echo "════════════════════════════════════════════"

NS_RESP=$(kestra_api   "${BASE}/namespaces/search")
ROLE_RESP=$(kestra_api "${BASE}/roles/search")
GRP_RESP=$(kestra_api  "${BASE}/groups/search")
SA_RESP=$(kestra_api  "${BASE}/service-accounts")

print_section() {
  local label="$1" response="$2" key="$3"
  local total
  total=$(echo "$response" | jq '.total // (.results | length)')
  echo ""
  echo "📋 ${label} — ${total} trouvé(s) :"
  echo "$response" | jq -r --arg k "$key" '.results[] | "  \(.[$k])\n    └─ uid : \(.id)"'
}

print_section "Namespaces" "$NS_RESP"   "id"
print_section "Rôles"      "$ROLE_RESP" "name"
print_section "Groupes"    "$GRP_RESP"  "name"
print_section "Service Accounts" "$SA_RESP" "name"
NS_MAP=$(echo   "$NS_RESP"   | jq '[.results[] | {key: .id,   value: .id}]   | from_entries')
ROLE_MAP=$(echo "$ROLE_RESP" | jq '[.results[] | {key: .name, value: .id}]   | from_entries')
GRP_MAP=$(echo  "$GRP_RESP"  | jq '[.results[] | {key: .name, value: .id}]   | from_entries')
SA_MAP=$(echo   "$SA_RESP"   | jq '[.results[] | {key: .name, value: .id}]   | from_entries')

jq -n \
  --argjson ns    "$NS_MAP" \
  --argjson roles "$ROLE_MAP" \
  --argjson grp   "$GRP_MAP" \
  --argjson sa    "$SA_MAP" \
  '{namespaces: $ns, roles: $roles, groups: $grp, service_accounts: $sa}' > "$OUTPUT_FILE"

echo ""
echo "════════════════════════════════════════════"
echo "📄 Fichier généré : ${OUTPUT_FILE}"
echo "   → Copiez les uid dans votre JSON de config Terraform"
echo "     pour les ressources déjà existantes dans Kestra."
echo "════════════════════════════════════════════"
echo ""
