#!/bin/bash

# Script pour capturer les tokens de service accounts Kestra lors de la création
# Usage: ./capture_tokens.sh <tenant_name>

set -e

TENANT_NAME=$1
if [ -z "$TENANT_NAME" ]; then
  echo "Usage: $0 <tenant_name>"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_FILE="$SCRIPT_DIR/../tokens/tokens-${TENANT_NAME}.txt"

mkdir -p "$(dirname "$OUTPUT_FILE")"

echo "════════════════════════════════════════════════════════════"
echo "  Récupération des tokens pour le tenant: $TENANT_NAME"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "⚠️  IMPORTANT : Les tokens ne sont visibles qu'UNE SEULE FOIS"
echo ""
echo "Pour récupérer les tokens manuellement :"
echo ""
echo "1️⃣  Via l'UI Kestra :"
echo "   - Ouvrez http://localhost:8888"
echo "   - Menu : Administration > Service Accounts"
echo "   - Sélectionnez le tenant : $TENANT_NAME"
echo "   - Cliquez sur chaque service account"
echo "   - Section 'API Tokens' : copiez le token affiché"
echo ""
echo "2️⃣  Via l'API Kestra (si vous avez un token admin) :"
echo ""
cat <<'EOF'
# Récupérer le token admin depuis Vault
export ADMIN_TOKEN=$(vault kv get -field=KESTRA_TOKEN_KM \
  cagip/stratus/tradi/prd-intranet/kestra/cagip/kestra-hprd-8b/isis)

# Lister les service accounts
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
  "http://localhost:8888/api/v1/service-accounts?tenantId=TENANT_NAME" | jq

# Créer un nouveau token pour un service account
curl -X POST \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "automation-token",
    "description": "Token for CI/CD",
    "maxAge": "P365D"
  }' \
  "http://localhost:8888/api/v1/service-accounts/SERVICE_ACCOUNT_ID/tokens?tenantId=TENANT_NAME"
EOF
echo ""
echo "3️⃣  Stockage sécurisé dans Vault :"
echo ""
echo "vault kv put cagip/stratus/tradi/prd-intranet/kestra/cagip/kestra-hprd-8b/isis/tokens \\"
echo "  sa-${TENANT_NAME}-dev='YOUR_TOKEN_HERE' \\"
echo "  sa-${TENANT_NAME}-int='YOUR_TOKEN_HERE'"
echo ""
echo "════════════════════════════════════════════════════════════"
echo ""
echo "📝 Tokens seront sauvegardés dans: $OUTPUT_FILE"
echo ""
read -p "Appuyez sur Entrée pour continuer..."
