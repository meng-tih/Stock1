#!/bin/bash

# Liste des projets
projects=("caa-kestra-hprd-07" "cagip-kestra-hprd-8b" "cagip-kestra-prd-58")

# Afficher la liste des projets
echo "Choisir le projet:"
for i in "${!projects[@]}"; do
    echo "$((i+1)): ${projects[$i]}"
done

read -p "Choisir le numero du projet: " choice

# Valider la saisie
length=${#projects[@]}
while [[ ! "$choice" =~ ^[0-9]+$ || $choice -lt 1 || $choice -gt $length ]]; do
    echo "Entrée invalide. Entrez un nombre entre 1 et $length."
    read -p "Choisir le numero du projet: " choice
done

# Set projet GCP
selected_project=${projects[$((choice-1))]}
gcloud config set project "$selected_project"
echo "Projet: $selected_project"

# Charger les variables depuis le fichier tfvars

# On découpe le nom du projet pour trouver le bon répertoire
IFS='-' read -r -a parts <<< "$selected_project"

# Logique pour déterminer left et right selon la structure du nom
if [[ "${parts[1]}" == "data" ]]; then
    # Cas: caa-data-xxx-yyy -> caa-data/xxx-yyy
    left="${parts[0]}-${parts[1]}"
    right=$(printf "%s-" "${parts[@]:2}" | sed 's/-$//')
else
    # Cas: caa-xxx-yyy -> caa/xxx-yyy
    left=${parts[0]}
    right=$(printf "%s-" "${parts[@]:1}" | sed 's/-$//')
fi

echo "$left | $right"

# On demande de choisir le cluster
repertoire="../terraform/instanciation/$left/$right"
if [[ ! -d "$repertoire" ]]; then
    echo "Repertoire du projet non trouvé : $repertoire"
    exit 1
fi

clusters=($(ls $repertoire/))
echo "Choisir le cluster:"
for i in "${!clusters[@]}"; do
    echo "$((i+1)): ${clusters[$i]}"
done
read -p "Choisir le numero du cluster: " choice

# Valider la saisie
length=${#clusters[@]}
while [[ ! "$choice" =~ ^[0-9]+$ || $choice -lt 1 || $choice -gt $length ]]; do
    echo "Entrée invalide. Entrez un nombre entre 1 et $length."
    read -p "Choisir le numero du cluster: " choice
done

# Lecture du tfvars
selected_cluster=${clusters[$((choice-1))]}
tfvars_file="$repertoire/$selected_cluster/$selected_cluster.tfvars"

if [[ ! -s "$tfvars_file" ]]; then
    echo "tfvars non trouvé : $tfvars_file"
    exit 1
fi

region=$(grep '^region' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
cluster_name=$(grep '^cluster_name' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
project_short_name=$(grep '^project_short_name' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
project_name=$(grep '^project_name' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
ptf_name=$(grep '^ptf_name' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
cluster_identifier=$(grep '^cluster_identifier' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
# Regle pour le cluster_name : coalesce(var.cluster_name, "${var.project_short_name}-kub-${var.ptf_name}-${var.cluster_identifier}")
default_cluster_name="$project_short_name-kub-$ptf_name-$cluster_identifier"
# Regle pour le bastion_name : coalesce(var.bastion_name, "${var.project_short_name}-gce-${var.ptf_name}-${var.bastion_identifier}")
bastion_name=$(grep '^bastion_name' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
bastion_identifier=$(grep '^bastion_identifier' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
zone=$(grep '^zone' "$tfvars_file" | awk -F'=' '{print $2}' | tr -d ' "')
default_bastion_name="$project_short_name-gce-$ptf_name-$bastion_identifier"
BASTION_NAME="${bastion_name:-${default_bastion_name}}"
CLUSTER_NAME="${cluster_name:-${default_cluster_name}}"

STATIC_IP_KESTRA=$(gcloud compute addresses describe ${selected_project}-iip-${ptf_name}-kestra-internal --format="value(address)" --region ${region})
echo "Lancement du tunnel vers ${STATIC_IP_KESTRA}..."
echo "zone : ${zone}"
echo "La connexion se fera via http://localhost:8888"
gcloud compute ssh ${BASTION_NAME} \
--zone "${zone}" \
--tunnel-through-iap \
-- -N -L 8888:${STATIC_IP_KESTRA}:80 \
-o ExitOnForwardFailure=yes \
-o ControlMaster=no \
-o ControlPersist=no

# TODO : Implémenter le deploiement des modules
# On recherche les modules disponibles (via leur main.tf)
MODULES_DIR="../terraform/modules"
modules=()
while IFS= read -r file; do
    module=$(dirname "$file" | sed "s|${MODULES_DIR}/||")
    modules+=("$module")
done < <(find ${MODULES_DIR} -name ".*" -prune -o -name "main.tf" -print)

# Afficher la liste des modules
echo "Choisir le module à déployer:"
for i in "${!modules[@]}"; do
    echo "$((i+1)): ${modules[$i]}"
done





