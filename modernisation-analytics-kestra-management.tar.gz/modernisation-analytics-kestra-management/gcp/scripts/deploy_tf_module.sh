#!/bin/bash
set -e

MODULE="$1"
TFVARS_FILE="$2"

case "$MODULE" in
  kmanager)
    echo "MODULE accepté : $MODULE"
    TERRAFORM_DIR="../terraform/modules/$MODULE"
    ;;
  *)
    echo "Erreur : MODULE doit être 'kmanager' (valeur fournie : $MODULE)"
    exit 1
    ;;
esac

# =============================================================================
# SÉLECTION INTERACTIVE DU CLUSTER (si TFVARS_FILE non fourni en argument)
# =============================================================================
if [[ -z "$TFVARS_FILE" ]]; then
  INSTANCIATION_DIR="../terraform/instanciation"

  # Choix du projet
  projects=($(ls "$INSTANCIATION_DIR/"))
  echo "Choisir le projet :"
  for i in "${!projects[@]}"; do
    echo "  $((i+1))) ${projects[$i]}"
  done
  read -p "Numéro du projet : " PROJ_CHOICE
  selected_project="${projects[$((PROJ_CHOICE-1))]}"

  # Choix de l'instance
  instances=($(ls "$INSTANCIATION_DIR/$selected_project/"))
  echo "Choisir l'instance :"
  for i in "${!instances[@]}"; do
    echo "  $((i+1))) ${instances[$i]}"
  done
  read -p "Numéro de l'instance : " INST_CHOICE
  selected_instance="${instances[$((INST_CHOICE-1))]}"

  # Choix du cluster
  clusters=($(ls "$INSTANCIATION_DIR/$selected_project/$selected_instance/"))
  echo "Choisir le cluster :"
  for i in "${!clusters[@]}"; do
    echo "  $((i+1))) ${clusters[$i]}"
  done
  read -p "Numéro du cluster : " CLUST_CHOICE
  selected_cluster="${clusters[$((CLUST_CHOICE-1))]}"

  TFVARS_FILE="$INSTANCIATION_DIR/$selected_project/$selected_instance/$selected_cluster/$selected_cluster.tfvars"
  echo "→ tfvars sélectionné : $TFVARS_FILE"
fi

# Fonction : extraire le nom du tenant depuis le fichier JSON
extract_tenant_name() {
  basename "$1" | sed 's/kestra-config-//;s/.json//'
}

# Configuration spécifique au module kmanager
if [[ "$MODULE" == "kmanager" ]]; then
  JSON_DIR="$(dirname "$TFVARS_FILE")/jsonconfig"
  [[ ! -d "$JSON_DIR" ]] && { echo "Erreur : Répertoire $JSON_DIR introuvable"; exit 1; }
  
  CONFIG_FILES=("$JSON_DIR"/kestra-config-*.json)
  [[ ! -e "${CONFIG_FILES[0]}" ]] && { echo "Erreur : Aucun fichier kestra-config-*.json dans $JSON_DIR"; exit 1; }
  
  # Affichage de la liste, sélection par numéro
  echo "Fichiers de configuration disponibles :"
  for i in "${!CONFIG_FILES[@]}"; do
    echo "  $((i+1))) $(extract_tenant_name "${CONFIG_FILES[$i]}")"
  done
  if [[ ${#CONFIG_FILES[@]} -eq 1 ]]; then
    SELECTED_CONFIG="${CONFIG_FILES[0]}"
    echo "→ Un seul tenant disponible, sélection automatique : $(extract_tenant_name "$SELECTED_CONFIG")"
  else
    read -p "Numéro du tenant : " TENANT_CHOICE
    if [[ ! "$TENANT_CHOICE" =~ ^[0-9]+$ ]] || (( TENANT_CHOICE < 1 || TENANT_CHOICE > ${#CONFIG_FILES[@]} )); then
      echo "Erreur : Choix invalide."
      exit 1
    fi
    SELECTED_CONFIG="${CONFIG_FILES[$((TENANT_CHOICE-1))]}"
  fi
  
  TENANT_NAME=$(extract_tenant_name "$SELECTED_CONFIG")
  export TF_VAR_config_file_path="$SELECTED_CONFIG"
  BACKEND_PREFIX="kmanager/tenant/${TENANT_NAME}"
  echo "→ Tenant: $TENANT_NAME | Config: $SELECTED_CONFIG | Backend: $BACKEND_PREFIX"
fi

if [[ ! -s "$TFVARS_FILE" ]]; then
    echo "tfvars non trouvés: $TFVARS_FILE"
    echo "Assurez-vous d'être dans le répertoire du script"
    exit 1
fi

if [[ ! -d "$TERRAFORM_DIR" ]]; then
    echo "Répertoire Terraform non trouvé: $TERRAFORM_DIR"
    echo "Assurez-vous d'être dans le répertoire du script"
    exit 1
fi

if [ -z "${VAULT_ROLE_ID:-}" -o -z "${VAULT_SECRET_ID:-}" ]; then
  echo "Il faut renseigner les variables (VAULT_ROLE_ID & VAULT_SECRET_ID) pour récupérer le mdp de la base SQL avec l'approle Vault"
  exit 1
else
  export TF_VAR_vault_role_id="$VAULT_ROLE_ID"
  export TF_VAR_vault_secret_id="$VAULT_SECRET_ID"
fi

# Lecture du fichier tfvars pour extraire les variables nécessaires au script
project_id=$(grep '^project_id' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
project_name=$(grep '^project_name' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
environment=$(grep '^environment' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
region=$(grep '^region' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
ptf_name=$(grep '^ptf_name' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
vault_addr=$(grep '^vault_addr' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
vault_secret_path=$(grep '^vault_secret_path' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')

# Ajout d'une alerte si certains flags autorisent la suppression d'objets
# Permet de detruire le bucket Kestra si true
force_destroy_bucket=$(grep '^force_destroy_bucket' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
# Permet de detruire l'instance cloudsql et ses objets. false permet de supprimer l'instance clousql
deletion_protection=$(grep '^deletion_protection' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')
# true permet de supprimer le user et ses objets
allow_user_deletion_with_objects=$(grep '^allow_user_deletion_with_objects' "$TFVARS_FILE" | awk -F'=' '{print $2}' | tr -d ' "')

if [ "$force_destroy_bucket" = "true" ] || [ "$deletion_protection" = "false" ] || [ "$allow_user_deletion_with_objects" = "true" ]; then
  echo "ATTENTION : force_destroy_bucket, deletion_protection ou allow_user_deletion_with_objects autorisent la suppression des objets"
  echo "Etes vous certain que ce sont les bons paramètres ? (oui pour continuer)"
  read a
  if [ "$a" != "oui" ]; then
    exit 1
  fi
fi

# On vérifie qu'elles sont toutes présentes
if [ -z "$project_id" ] || [ -z "$project_name" ] || [ -z "$environment" ] || [ -z "$region" ] || [ -z "$ptf_name" ] || [ -z "$vault_addr" ] || [ -z "$vault_secret_path" ]; then
  echo "Erreur: Une ou plusieurs variables sont absentes du fichier $TFVARS_FILE"
  exit 1
fi

echo "project_id: $project_id"
echo "project_name: $project_name"
echo "environment: $environment"
echo "region: $region"
echo "ptf_name: $ptf_name"
echo "vault_addr: $vault_addr"
echo "vault_secret_path: $vault_secret_path"


# Set projet
gcloud config set project "$project_id"


# Lancement du script terraform
cd "$TERRAFORM_DIR"

# Suppression des tfstate temporaire
rm -rf .terraform
rm -f .terraform.lock.hcl

# Initialisation Terraform
echo "Initialisation Terraform..."

terraform init

echo "Quelle action souhaitée ? (plan, apply ou destroy)"
read ACTION

case $ACTION in 
  plan)
    # Validation Terraform
    echo "Validation de la configuration..."
    terraform validate
    echo "Génération du plan Terraform..."
    terraform plan \
        -var-file="$TFVARS_FILE" \
        -out=tfplan
    ;;
  apply)
    # Validation Terraform
    echo "Validation de la configuration..."
    terraform validate
    echo "Application du plan Terraform..."
    echo "Génération du plan Terraform..."
    terraform plan \
        -var-file="$TFVARS_FILE" \
        -out=tfplan

    echo "Go ? (CTRL +C pour annuler)"
    read a

    # Application Terraform
    terraform apply tfplan
    ;;
  destroy)
    echo "Destroy ? (taper oui)"
    read destroy_validation

    if [[ "$destroy_validation" == "oui" ]]; then
      terraform validate
      terraform plan -destroy -var-file="$TFVARS_FILE" -out=tfplan-destroy
      echo "Go ? (CTRL +C pour annuler)"
      read a
      terraform apply tfplan-destroy
    else
      echo "Destroy annulé"
      exit 1
    fi 
    ;;
  *)
    echo "ACTION doit être plan, apply ou destroy (valeur fournie : $ACTION)"
    exit 1
    ;;
esac


# # Validation Terraform
# echo "Validation de la configuration..."
# terraform validate

# # Plan Terraform
# echo "Génération du plan Terraform..."
# terraform plan \
#      -var-file="$TFVARS_FILE" \
#      -out=tfplan

# echo "Go ? (CTRL +C pour annuler)"
# read a

# # Application Terraform
# terraform apply tfplan

# echo "Destroy ? (taper oui)"
# read destroy_validation

# # Destroy Terraform
# if [[ "$destroy_validation" == "oui" ]]; then
#     if [[ "$MODULE" == "kmanager" && -n "$BACKEND_PREFIX" ]]; then
#       terraform init -backend-config="bucket=$bucket_tfstate" -backend-config="prefix=$BACKEND_PREFIX"
#     else
#       terraform init -backend-config="bucket=$bucket_tfstate"
#     fi
#     terraform validate
#     # On gère le cas particulier du module accounts. la ressource google_service_account.sa_gcp_kestra
#     # ne peut pas être détruite, seulement créé. Donc on la supprime du state pour ne pas avoir d'erreur
#     # lors du destroy.
#     # la création est assujetie à un flag dans le tfvars, il faut le mettre à false une fois une première
#     # installation effectuée.
#     if [[ "$MODULE" == "accounts" ]]; then
#       if terraform state list | grep -q "google_service_account.sa_gcp_kestra"; then
#         terraform state rm google_service_account.sa_gcp_kestra
#       fi
#     fi
#     terraform plan -destroy -var-file="$TFVARS_FILE" -out=tfplan-destroy
#     echo "Go ? (CTRL +C pour annuler)"
#     read a
#     terraform apply tfplan-destroy
# fi
