#export HTTPS_PROXY=http://10.245.103.24:8080 
export instanciation="caa/kestra-hprd-07/thot/thot"
