# Ce que CAAS doit implémenter dans les repoS CI applicatifs

## Principe

Les repoS CI applicatifs CAAS déclenchent le pipeline GitLab du repo `v7_cd_usage_entrypoint` avec les variables nécessaires.

Ils ne modifient pas les fichiers `params.json`. Ces fichiers sont maintenus manuellement par GEA dans `v7_cd_usage_entrypoint`.

## Pré-requis côté CAAS

Avant d'appeler la CD :

```text
dev     : l'image doit exister dans Artifactory scratch
int/rec : l'image doit exister dans Artifactory staging
```

Le dépôt CD ne fait pas de promote d'image.

## Exemple de job GitLab côté CAAS

```yaml
trigger_cd_usage:
  stage: deploy
  image: curlimages/curl:latest
  script:
    - |
      curl --fail --request POST \
        --form token="${V7_CD_USAGE_ENTRYPOINT_TRIGGER_TOKEN}" \
        --form ref="${V7_CD_USAGE_ENTRYPOINT_REF:-main}" \
        --form "variables[TARGET_ENVIRONMENT]=${TARGET_ENVIRONMENT}" \
        --form "variables[NAME]=${NAME}" \
        --form "variables[GROUP_ID]=${GROUP_ID}" \
        --form "variables[VERSION]=${VERSION}" \
        "${CI_API_V4_URL}/projects/${V7_CD_USAGE_ENTRYPOINT_PROJECT_ID}/trigger/pipeline"
```

## Appel pour dev

```text
TARGET_ENVIRONMENT=dev
NAME=sinfs
GROUP_ID=fr.caa.systemeentreprise.pilotage.ma
VERSION=0.0.15
```

Autre exemple :

```text
TARGET_ENVIRONMENT=dev
NAME=ma-dsd-sinbdo-domsin
GROUP_ID=fr.caa.systemeentreprise.pilotage.ma
VERSION=0.0.15
```

## Appel pour int

Minimum :

```text
TARGET_ENVIRONMENT=int
NAME=sinfs
```

Avec surcharge possible :

```text
TARGET_ENVIRONMENT=int
NAME=sinfs
VERSION=0.0.16
```

## Appel pour rec

Minimum :

```text
TARGET_ENVIRONMENT=rec
NAME=sinfs
```

Avec surcharge possible :

```text
TARGET_ENVIRONMENT=rec
NAME=sinfs
GROUP_ID=fr.caa.systemeentreprise.pilotage.ma
VERSION=0.0.16
```

## Ce que fait `v7_cd_usage_entrypoint`

À partir de `NAME`, le repo vérifie :

```text
usages/<NAME>/params.json
```

Puis il récupère le project id cible correspondant à l'environnement demandé.

Exemple :

```json
{
  "dev": "caa-data-domsin-dev-e7",
  "int": "caa-data-domsin-int-ca",
  "rec": "caa-data-domsin-rec-ee"
}
```

Pour `int` et `rec`, si `GROUP_ID` ou `VERSION` ne sont pas fournis, ils sont repris depuis :

```text
usages/<NAME>/manifests/dev.json
```

## Erreur attendue si l'usage n'est pas référencé par GEA

Si `usages/<NAME>/params.json` n'existe pas dans `v7_cd_usage_entrypoint`, le pipeline échoue.

Message attendu :

```text
Usage non référencé par GEA
```

## Erreur attendue si le project id est absent

Si `params.json` ne contient pas l'environnement demandé, le pipeline échoue.

Exemple :

```text
Aucun project_id trouvé pour env=rec dans usages/<NAME>/params.json
```

## Retour d'erreur

`v7_cd_usage_entrypoint` déclenche `v7_cd_usage` avec `strategy: depend`.

Conséquence : si le déploiement Terraform échoue dans `v7_cd_usage`, l'échec remonte à `v7_cd_usage_entrypoint`, puis à la CI applicative CAAS.
