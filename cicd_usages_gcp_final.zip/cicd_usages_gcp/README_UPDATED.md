# Kit CI/CD usages GCP

Ce kit contient deux dépôts Git complémentaires :

```text
repoS CI applicatifs CAAS
  -> v7_cd_usage_entrypoint
    -> v7_cd_usage
      -> GCP project cible
```

## Dépôts

### `v7_cd_usage_entrypoint`

Repo d'entrée appelé par les repoS CI applicatifs CAAS.

Il sert à :

1. vérifier que l'usage est référencé par GEA ;
2. lire le project id cible dans `usages/<NAME>/params.json` ;
3. résoudre les valeurs effectives `GROUP_ID`, `VERSION`, `TARGET_PROJECT`, `SOURCE_REPOSITORY` ;
4. maintenir les manifests `usages/<NAME>/manifests/<env>.json` ;
5. déclencher `v7_cd_usage` avec `strategy: depend`.

### `v7_cd_usage`

Repo de déploiement Terraform.

Il sert à :

1. générer le YAML usage `usages/<env>/<NAME>.yaml` ;
2. initialiser Terraform avec un state isolé ;
3. tirer l'image depuis Artifactory ;
4. pousser l'image vers GAR ;
5. déployer ou détruire les ressources GCP de l'usage.

## Environnements supportés

```text
dev
int
rec
```

Pas de `pprd` / `prd` dans ce modèle simplifié.

## Règles image

```text
dev     -> Artifactory scratch
int/rec -> Artifactory staging
```

Le kit ne fait pas de promote d'image et ne fait pas de scan image.

## Règle de nommage `NAME`

`NAME` est l'identifiant complet de l'usage.

Exemples valides :

```text
sinfs
dsd-sinfs
ma-dsd-sinbdo-domsin
ma_dsd_sinbdo_domsin
```

Le code ne découpe plus `NAME` pour déduire un domaine ou un `usage_short`.

## Domaine GCP

Le domaine est déduit depuis le `TARGET_PROJECT`, juste avant l'environnement.

Exemple :

```text
TARGET_PROJECT     = caa-data-domsin-dev-e7
TARGET_ENVIRONMENT = dev
DOMAIN             = domsin
```

Cette règle évite les erreurs lorsque le `NAME` ne contient pas le domaine.

## Backend Terraform

Le state Terraform est isolé par domaine, environnement et `NAME` complet :

```text
gs://tfstate-caa-apps-usage-hprd/<domain>/<env>/<NAME>/default.tfstate
```

Exemple :

```text
NAME               = sinfs
TARGET_PROJECT     = caa-data-domsin-dev-e7
TARGET_ENVIRONMENT = dev
TF_BACKEND_PREFIX  = domsin/dev/sinfs
```

## Impersonation GCP

Le pipeline `v7_cd_usage` utilise le modèle suivant :

```text
WIF GitLab
  -> iac-wif-usage-sa@caa-cicd-usage-hprd-d6
  -> iac-deploy-usage-sa@caa-cicd-usage-hprd-d6
```

Le SA central est utilisé pour accéder au bucket Terraform state et au GAR central.

Ensuite, les providers Terraform Google impersonent le SA de déploiement du projet usage :

```text
iac-deploy-usage-sa@<TARGET_PROJECT>.iam.gserviceaccount.com
```

## Destroy

Le destroy est lancé directement depuis `v7_cd_usage`, pas depuis `v7_cd_usage_entrypoint`.

Paramètres minimaux :

```text
ACTION=destroy
TARGET_ENVIRONMENT=dev|int|rec
NAME=<usage>
TARGET_PROJECT=<project id usage>
```

`terraform_destroy_plan` est automatique. `terraform_destroy_apply` reste manuel.

## Points d'attention

- `GIT_PUSH_TOKEN` est nécessaire dans `v7_cd_usage_entrypoint` pour commiter les manifests si ceux-ci changent.
- `CD_USAGE_PROJECT_NAME` doit pointer vers le repo `v7_cd_usage`.
- `CD_USAGE_REF` vaut `main` par défaut, mais peut être surchargé pour tester une branche.
- Le repo GitLab `v7_cd_usage` doit être autorisé dans la WIF sur `iac-wif-usage-sa`.
- Le SA central doit pouvoir impersonate les SA applicatifs des projets usages.
