# Questions à poser à CAAS

## 1. Nommage officiel de l'usage

Confirmer la valeur officielle du `NAME` envoyé à la CD.

Exemples acceptés côté CD :

```text
sinfs
dsd-sinfs
ma-dsd-sinbdo-domsin
ma_dsd_sinbdo_domsin
```

Règle actuelle côté CD :

```text
NAME = identifiant complet de l'usage
```

Le `NAME` n'est plus découpé pour déterminer le domaine.

## 2. Domaine et project id GCP

Confirmer que le domaine fonctionnel doit être déduit du project id cible GCP.

Exemple :

```text
TARGET_PROJECT     = caa-data-domsin-dev-e7
TARGET_ENVIRONMENT = dev
DOMAIN             = domsin
```

Cette règle est utilisée pour :

```text
GAR repository : domain-ar-caa-data-<domain>
TF state       : <domain>/<env>/<NAME>/default.tfstate
```

## 3. Images Docker disponibles avant appel CD

Confirmer que l'image existe déjà avant l'appel à `v7_cd_usage_entrypoint` :

```text
dev     -> Artifactory scratch
int/rec -> Artifactory staging
```

Si l'image n'existe pas, le déploiement CD échoue et l'erreur doit remonter à la CI applicative CAAS.

## 4. Variables envoyées par les repoS CI applicatifs CAAS

Pour `dev`, variables obligatoires :

```text
TARGET_ENVIRONMENT=dev
NAME=<usage>
GROUP_ID=<groupId Maven / chemin Artifactory logique>
VERSION=<tag image Docker>
```

Pour `int` et `rec`, variables obligatoires :

```text
TARGET_ENVIRONMENT=int|rec
NAME=<usage>
```

Variables optionnelles pour `int` et `rec` :

```text
GROUP_ID=<surcharge éventuelle>
VERSION=<surcharge éventuelle>
```

Si `GROUP_ID` ou `VERSION` ne sont pas fournis en `int` / `rec`, la CD reprend les valeurs du manifest `dev.json`.

## 5. Repository Artifactory source

Confirmer que :

```text
dev     -> caas-shared-docker-scratch-intranet
int/rec -> caas-shared-docker-staging-intranet
```

## 6. Tag image

Confirmer que la variable `VERSION` correspond exactement au tag Docker à déployer.

Exemple :

```text
VERSION=0.0.15
image=<registry>/<GROUP_PATH>/<NAME>:0.0.15
```

## 7. Pas de chaînage automatique

Confirmer que la CD ne doit pas enchaîner automatiquement :

```text
dev -> int -> rec
```

Chaque environnement doit être déclenché explicitement par la CI applicative CAAS ou par un lancement manuel GEA.

## 8. Chemin Artifactory

Confirmer que le chemin image est construit par transformation du `GROUP_ID` :

```text
GROUP_ID=fr.caa.systemeentreprise.pilotage.ma
GROUP_PATH=fr/caa/systemeentreprise/pilotage/ma
```

Image source finale :

```text
<registry>/<GROUP_PATH>/<NAME>:<VERSION>
```

## 9. Référencement GEA obligatoire

Confirmer que CAAS accepte le comportement suivant : si `usages/<NAME>/params.json` n'existe pas dans `v7_cd_usage_entrypoint`, le pipeline échoue.

Message attendu :

```text
Usage non référencé par GEA
```

## 10. Contrat de retour d'erreur

Confirmer que si `v7_cd_usage_entrypoint` ou `v7_cd_usage` échoue, la CI applicative CAAS doit être considérée en échec.
