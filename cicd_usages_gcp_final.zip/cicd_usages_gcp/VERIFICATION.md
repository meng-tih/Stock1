# Vérifications réalisées

## Syntaxe

- `bash -n` exécuté sur tous les scripts des deux repos : OK.
- Parsing YAML des `.gitlab-ci.yml` et fichiers `terraform/config/*.yaml` : OK.

## Simulations locales sans accès GCP

### `v7_cd_usage_entrypoint`

Cas testés :

```text
TARGET_ENVIRONMENT=dev
NAME=sinfs
GROUP_ID=fr.caa.test
VERSION=1.2.3
```

Résultat :

```text
TARGET_PROJECT=caa-data-domsin-dev-e7
SOURCE_REPOSITORY=scratch
manifest dev résolu correctement
```

Cas testé pour `int` sans surcharge `GROUP_ID` / `VERSION` :

```text
TARGET_ENVIRONMENT=int
NAME=sinfs
```

Résultat :

```text
GROUP_ID repris depuis dev.json
VERSION repris depuis dev.json
TARGET_PROJECT=caa-data-domsin-int-ca
SOURCE_REPOSITORY=staging
```

### `v7_cd_usage`

Cas deploy testé :

```text
ACTION=deploy
TARGET_ENVIRONMENT=dev
NAME=sinfs
TARGET_PROJECT=caa-data-domsin-dev-e7
GROUP_ID=fr.caa.test
VERSION=1.2.3
```

Résultat attendu obtenu :

```text
DOMAIN=domsin
BUCKET_NAME=caa-data-domsin-dev-gcs-europe-west1-sinfs
TF_VAR_usage_key=sinfs
```

Cas destroy testé :

```text
ACTION=destroy
TARGET_ENVIRONMENT=dev
NAME=dsd-sinfs
TARGET_PROJECT=caa-data-domsin-dev-e7
```

Résultat attendu obtenu :

```text
DOMAIN=domsin
BUCKET_NAME=caa-data-domsin-dev-gcs-europe-west1-dsd-sinfs
GROUP_ID=destroy.local
VERSION=0.0.0-destroy
```

## Points non exécutés localement

Les appels réels suivants nécessitent l'environnement GitLab / GCP :

- Workload Identity Federation GitLab -> GCP ;
- accès au bucket `tfstate-caa-apps-usage-hprd` ;
- pull/push Docker Artifactory/GAR ;
- `terraform plan/apply` réel.
