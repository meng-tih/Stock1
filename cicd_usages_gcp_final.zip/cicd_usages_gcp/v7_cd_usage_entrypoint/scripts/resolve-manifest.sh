#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

: "${TARGET_ENVIRONMENT:?Variable obligatoire manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable obligatoire manquante: NAME}"

PARAMS_FILE="usages/${NAME}/params.json"
[ -f "${PARAMS_FILE}" ] || fail "Usage non référencé par GEA: ${PARAMS_FILE} est manquant."

TARGET_PROJECT="$(jq -r --arg env "${TARGET_ENVIRONMENT}" '.[$env] // empty' "${PARAMS_FILE}")"
[ -n "${TARGET_PROJECT}" ] || fail "Aucun project_id trouvé pour env=${TARGET_ENVIRONMENT} dans ${PARAMS_FILE}"

if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
  : "${GROUP_ID:?GROUP_ID est requis en dev}"
  : "${VERSION:?VERSION est requis en dev}"
  SOURCE_REPOSITORY="scratch"
  RESOLVED_GROUP_ID="${GROUP_ID}"
  RESOLVED_VERSION="${VERSION}"
else
  SOURCE_REPOSITORY="staging"
  DEV_MANIFEST="usages/${NAME}/manifests/dev.json"
  [ -f "${DEV_MANIFEST}" ] || fail "Manifest dev introuvable: ${DEV_MANIFEST}"

  DEV_GROUP_ID="$(jq -r '.groupId // empty' "${DEV_MANIFEST}")"
  DEV_VERSION="$(jq -r '.version // empty' "${DEV_MANIFEST}")"

  [ -n "${DEV_GROUP_ID}" ] || fail "groupId absent dans ${DEV_MANIFEST}"
  [ -n "${DEV_VERSION}" ] || fail "version absente dans ${DEV_MANIFEST}"

  # En int/rec, GROUP_ID et VERSION sont optionnels et surchargent dev.json si fournis.
  RESOLVED_GROUP_ID="${GROUP_ID:-${DEV_GROUP_ID}}"
  RESOLVED_VERSION="${VERSION:-${DEV_VERSION}}"
fi

MANIFEST_PATH="usages/${NAME}/manifests/${TARGET_ENVIRONMENT}.json"
mkdir -p "$(dirname "${MANIFEST_PATH}")"

cat > deploy.env <<EOF_ENV
ACTION=deploy
GROUP_ID=${RESOLVED_GROUP_ID}
NAME=${NAME}
VERSION=${RESOLVED_VERSION}
TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}
TARGET_PROJECT=${TARGET_PROJECT}
SOURCE_REPOSITORY=${SOURCE_REPOSITORY}
MANIFEST_PATH=${MANIFEST_PATH}
EOF_ENV

jq -n \
  --arg groupId "${RESOLVED_GROUP_ID}" \
  --arg name "${NAME}" \
  --arg version "${RESOLVED_VERSION}" \
  --arg targetEnvironment "${TARGET_ENVIRONMENT}" \
  --arg targetProject "${TARGET_PROJECT}" \
  --arg sourceRepository "${SOURCE_REPOSITORY}" \
  '{
    groupId: $groupId,
    name: $name,
    version: $version,
    targetEnvironment: $targetEnvironment,
    targetProject: $targetProject,
    sourceRepository: $sourceRepository
  }' > "${MANIFEST_PATH}.resolved"

echo "Manifest résolu: ${MANIFEST_PATH}"
echo "GROUP_ID=${RESOLVED_GROUP_ID}"
echo "VERSION=${RESOLVED_VERSION}"
echo "TARGET_PROJECT=${TARGET_PROJECT}"
echo "SOURCE_REPOSITORY=${SOURCE_REPOSITORY}"
