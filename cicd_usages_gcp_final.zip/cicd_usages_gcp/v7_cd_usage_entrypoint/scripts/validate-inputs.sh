#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

ACTION="${ACTION:-deploy}"

if [ "${ACTION}" != "deploy" ]; then
  fail "v7_cd_usage_entrypoint supporte uniquement ACTION=deploy. Pour un destroy, lancer manuellement le pipeline v7_cd_usage."
fi

: "${TARGET_ENVIRONMENT:?Variable obligatoire manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable obligatoire manquante: NAME}"

case "${TARGET_ENVIRONMENT}" in
  dev|int|rec) ;;
  *) fail "TARGET_ENVIRONMENT invalide: ${TARGET_ENVIRONMENT}. Valeurs autorisées: dev, int, rec" ;;
esac

# NAME sert d'identifiant complet de l'usage, de clé Terraform et de chemin de manifest.
# On interdit les slashs et caractères exotiques pour éviter les chemins inattendus.
if ! printf '%s' "${NAME}" | grep -Eq '^[A-Za-z0-9._-]+$'; then
  fail "NAME invalide: ${NAME}. Caractères autorisés: lettres, chiffres, point, tiret, underscore"
fi

PARAMS_FILE="usages/${NAME}/params.json"
DEV_MANIFEST="usages/${NAME}/manifests/dev.json"

[ -d "usages/${NAME}" ] || fail "Usage non référencé par GEA: usages/${NAME} n'existe pas. GEA doit créer le dossier et le params.json avant le déploiement."
[ -f "${PARAMS_FILE}" ] || fail "Usage non référencé par GEA: ${PARAMS_FILE} est manquant."

if ! jq empty "${PARAMS_FILE}" >/dev/null 2>&1; then
  fail "JSON invalide: ${PARAMS_FILE}"
fi

TARGET_PROJECT_FROM_PARAMS="$(jq -r --arg env "${TARGET_ENVIRONMENT}" '.[$env] // empty' "${PARAMS_FILE}")"
[ -n "${TARGET_PROJECT_FROM_PARAMS}" ] || fail "Aucun project_id trouvé pour env=${TARGET_ENVIRONMENT} dans ${PARAMS_FILE}"

# Le domaine est déduit du project id cible : caa-data-<domain>-<env>-<suffix>.
if [ "${TARGET_PROJECT_FROM_PARAMS%-${TARGET_ENVIRONMENT}-*}" = "${TARGET_PROJECT_FROM_PARAMS}" ]; then
  fail "project_id=${TARGET_PROJECT_FROM_PARAMS} ne permet pas de déduire le domaine avec TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
fi

if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
  : "${GROUP_ID:?Variable obligatoire manquante en dev: GROUP_ID}"
  : "${VERSION:?Variable obligatoire manquante en dev: VERSION}"
else
  [ -f "${DEV_MANIFEST}" ] || fail "${DEV_MANIFEST} est requis pour déployer ${TARGET_ENVIRONMENT}. Lancez d'abord un déploiement dev ou créez le manifest dev de référence."
  DEV_GROUP_ID="$(jq -r '.groupId // empty' "${DEV_MANIFEST}")"
  DEV_VERSION="$(jq -r '.version // empty' "${DEV_MANIFEST}")"
  [ -n "${DEV_GROUP_ID}" ] || fail "groupId absent dans ${DEV_MANIFEST}"
  [ -n "${DEV_VERSION}" ] || fail "version absente dans ${DEV_MANIFEST}"
fi

echo "Validation OK"
echo "ACTION=deploy"
echo "NAME=${NAME}"
echo "TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
echo "TARGET_PROJECT=${TARGET_PROJECT_FROM_PARAMS}"
if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
  echo "GROUP_ID=${GROUP_ID}"
  echo "VERSION=${VERSION}"
else
  echo "GROUP_ID=${GROUP_ID:-repris depuis dev.json}"
  echo "VERSION=${VERSION:-repris depuis dev.json}"
fi
