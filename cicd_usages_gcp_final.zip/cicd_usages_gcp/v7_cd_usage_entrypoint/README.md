# v7_cd_usage_entrypoint

Repo d'entrée CD pour les usages applicatifs CAAS.

## Rôle

Ce repo ne déploie rien dans GCP. Il sert à :

1. recevoir l'appel des repoS CI applicatifs CAAS ;
2. contrôler que l'usage a été référencé par GEA ;
3. lire le project id cible dans `usages/<NAME>/params.json` ;
4. résoudre les variables effectives de déploiement ;
5. créer ou mettre à jour le manifest de référence ;
6. déclencher le repo `v7_cd_usage` avec `strategy: depend` pour remonter l'échec à la CI appelante.

Modèle :

```text
repoS CI applicatifs CAAS
  -> v7_cd_usage_entrypoint
    -> v7_cd_usage
      -> GCP project cible
```

## Structure

```text
usages/
  <NAME>/
    params.json
    manifests/
      dev.json
      int.json
      rec.json
```

`usages/<NAME>/params.json` est créé et maintenu manuellement par GEA. Si le dossier ou le fichier n'existe pas, le pipeline échoue.

## Exemple `params.json`

```json
{
  "dev": "caa-data-domsin-dev-e7",
  "int": "caa-data-domsin-int-ca",
  "rec": "caa-data-domsin-rec-ee"
}
```

## Règles de nommage

`NAME` est l'identifiant complet de l'usage. Il n'est plus découpé pour déterminer le domaine.

Exemples valides :

```text
sinfs
dsd-sinfs
ma-dsd-sinbdo-domsin
ma_dsd_sinbdo_domsin
```

Le domaine est déduit plus tard par `v7_cd_usage` depuis le `TARGET_PROJECT`.

Exemple :

```text
TARGET_PROJECT=caa-data-domsin-dev-e7
TARGET_ENVIRONMENT=dev
domain=domsin
```

## Variables d'entrée

### Dev

Variables obligatoires :

```text
TARGET_ENVIRONMENT=dev
NAME=<usage>
GROUP_ID=<groupId Maven / chemin Artifactory logique>
VERSION=<tag image Docker>
```

### Int / Rec

Variables obligatoires :

```text
TARGET_ENVIRONMENT=int|rec
NAME=<usage>
```

Variables optionnelles :

```text
GROUP_ID=<surcharge éventuelle>
VERSION=<surcharge éventuelle>
```

Si `GROUP_ID` ou `VERSION` ne sont pas fournis en `int` / `rec`, les valeurs sont reprises depuis `usages/<NAME>/manifests/dev.json`.

## Source repository image

```text
dev     -> scratch
int/rec -> staging
```

Le repo ne fait pas de promote d'image.

## Variables GitLab à configurer

```text
GIT_PUSH_TOKEN
CD_USAGE_PROJECT_NAME
CD_USAGE_REF
DOCKER_HUB_MIRROR
```

`CD_USAGE_PROJECT_NAME` doit contenir le chemin GitLab du repo `v7_cd_usage`, par exemple :

```text
gea/sid/cd/centralisationinformation/collectedonnee/v7/v7_cd_usage
```

`CD_USAGE_REF` vaut `main` par défaut.

`GIT_PUSH_TOKEN` est requis uniquement quand le manifest doit être modifié et commité.

## Destroy

Le destroy ne passe pas par ce repo. Il est lancé manuellement depuis `v7_cd_usage` avec :

```text
ACTION=destroy
TARGET_ENVIRONMENT=<dev|int|rec>
NAME=<usage>
TARGET_PROJECT=<project id usage>
```
