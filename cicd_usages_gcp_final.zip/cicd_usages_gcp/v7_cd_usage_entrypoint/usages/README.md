# Référentiel usages GEA

Chaque usage doit être référencé par GEA avant tout déploiement.

Structure attendue :

```text
usages/
  <NAME>/
    params.json
    manifests/
      dev.json
      int.json
      rec.json
```

`params.json` contient les project ids GCP par environnement :

```json
{
  "dev": "caa-data-domsin-dev-e7",
  "int": "caa-data-domsin-int-ca",
  "rec": "caa-data-domsin-rec-ee"
}
```

Les fichiers `manifests/*.json` sont générés par le pipeline. Ils ne doivent pas être modifiés manuellement, sauf besoin exceptionnel GEA.
