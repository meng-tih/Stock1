#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

ACTION="${ACTION:-deploy}"

: "${TARGET_ENVIRONMENT:?TARGET_ENVIRONMENT est requis}"
: "${NAME:?NAME est requis}"
: "${TARGET_PROJECT:?TARGET_PROJECT est requis}"

case "${ACTION}" in
  deploy|destroy) ;;
  *) fail "ACTION invalide: ${ACTION}. Valeurs autorisées: deploy, destroy" ;;
esac

if ! printf '%s' "${NAME}" | grep -Eq '^[A-Za-z0-9._-]+$'; then
  fail "NAME invalide: ${NAME}. Caractères autorisés: lettres, chiffres, point, tiret, underscore"
fi

# En destroy, Terraform a quand même besoin du YAML usage pour charger sa configuration,
# mais l'image n'est pas réellement utilisée.
if [ "${ACTION}" = "destroy" ]; then
  GROUP_ID="${GROUP_ID:-destroy.local}"
  VERSION="${VERSION:-0.0.0-destroy}"
  SOURCE_REPOSITORY="${SOURCE_REPOSITORY:-scratch}"
else
  : "${GROUP_ID:?GROUP_ID est requis en deploy}"
  : "${VERSION:?VERSION est requis en deploy}"

  if [ -z "${SOURCE_REPOSITORY:-}" ]; then
    if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
      SOURCE_REPOSITORY="scratch"
    else
      SOURCE_REPOSITORY="staging"
    fi
  fi
fi

case "${SOURCE_REPOSITORY}" in
  scratch|staging) ;;
  *) fail "SOURCE_REPOSITORY invalide: ${SOURCE_REPOSITORY}. Valeurs autorisées: scratch, staging" ;;
esac

GROUP_PATH="${GROUP_ID//./\/}"

# Domaine déduit depuis le project id cible, pas depuis NAME.
# Exemple : caa-data-domsin-dev-e7 + dev => domsin
PROJECT_BEFORE_ENV="${TARGET_PROJECT%-${TARGET_ENVIRONMENT}-*}"
if [ "${PROJECT_BEFORE_ENV}" = "${TARGET_PROJECT}" ]; then
  fail "Impossible de déduire DOMAIN depuis TARGET_PROJECT=${TARGET_PROJECT} avec TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
fi
DOMAIN="${PROJECT_BEFORE_ENV##*-}"

PROJECT_PREFIX="${TARGET_PROJECT%-*}"
REGION="${REGION:-europe-west1}"

# NAME est utilisé en entier. Pour le bucket GCS, on normalise seulement les underscores
# car GCS n'accepte pas '_' dans les noms de bucket.
BUCKET_USAGE_NAME="$(printf '%s' "${NAME}" | tr '[:upper:]' '[:lower:]' | tr '_' '-')"
BUCKET_NAME="${BUCKET_NAME_OVERRIDE:-${PROJECT_PREFIX}-gcs-${REGION}-${BUCKET_USAGE_NAME}}"

mkdir -p "usages/${TARGET_ENVIRONMENT}"
USAGE_FILE="usages/${TARGET_ENVIRONMENT}/${NAME}.yaml"

sed \
  -e "s|__NAME__|${NAME}|g" \
  -e "s|__IMAGE_NAME__|${NAME}|g" \
  -e "s|__GROUP_ID__|${GROUP_ID}|g" \
  -e "s|__GROUP_PATH__|${GROUP_PATH}|g" \
  -e "s|__VERSION__|${VERSION}|g" \
  -e "s|__DOMAIN__|${DOMAIN}|g" \
  -e "s|__TARGET_ENVIRONMENT__|${TARGET_ENVIRONMENT}|g" \
  -e "s|__TARGET_PROJECT__|${TARGET_PROJECT}|g" \
  -e "s|__SOURCE_REPOSITORY__|${SOURCE_REPOSITORY}|g" \
  -e "s|__BUCKET_NAME__|${BUCKET_NAME}|g" \
  templates/usage.yaml.tpl > "${USAGE_FILE}"

cat > deploy.env <<EOF_ENV
ACTION=${ACTION}
USAGE_FILE=${USAGE_FILE}
GROUP_PATH=${GROUP_PATH}
DOMAIN=${DOMAIN}
PROJECT_PREFIX=${PROJECT_PREFIX}
BUCKET_NAME=${BUCKET_NAME}
SOURCE_REPOSITORY=${SOURCE_REPOSITORY}
TF_VAR_environment=${TARGET_ENVIRONMENT}
TF_VAR_usage_key=${NAME}
EOF_ENV

echo "YAML d'usage généré: ${USAGE_FILE}"
echo "DOMAIN=${DOMAIN}"
echo "NAME=${NAME}"
echo "BUCKET_NAME=${BUCKET_NAME}"
cat "${USAGE_FILE}"
