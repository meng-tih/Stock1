#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

ACTION="${ACTION:-deploy}"

case "${ACTION}" in
  deploy|destroy) ;;
  *) fail "ACTION invalide: ${ACTION}. Valeurs autorisées: deploy, destroy" ;;
esac

: "${TARGET_ENVIRONMENT:?Variable obligatoire manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable obligatoire manquante: NAME}"
: "${TARGET_PROJECT:?Variable obligatoire manquante: TARGET_PROJECT}"

case "${TARGET_ENVIRONMENT}" in
  dev|int|rec) ;;
  *) fail "TARGET_ENVIRONMENT invalide: ${TARGET_ENVIRONMENT}. Valeurs autorisées: dev, int, rec" ;;
esac

# Sécurité : NAME sert au chemin de state et au nom de fichier YAML généré.
# On interdit les slashs et caractères exotiques pour éviter les chemins inattendus.
if ! printf '%s' "${NAME}" | grep -Eq '^[A-Za-z0-9._-]+$'; then
  fail "NAME invalide: ${NAME}. Caractères autorisés: lettres, chiffres, point, tiret, underscore"
fi

# Le domaine est déduit du project id cible : caa-data-<domain>-<env>-<suffix>.
if [ "${TARGET_PROJECT%-${TARGET_ENVIRONMENT}-*}" = "${TARGET_PROJECT}" ]; then
  fail "TARGET_PROJECT=${TARGET_PROJECT} ne permet pas de déduire le domaine avec TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
fi

if [ "${ACTION}" = "deploy" ]; then
  : "${GROUP_ID:?Variable obligatoire manquante en deploy: GROUP_ID}"
  : "${VERSION:?Variable obligatoire manquante en deploy: VERSION}"

  # Par défaut : dev=scratch, int/rec=staging.
  if [ -z "${SOURCE_REPOSITORY:-}" ]; then
    if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
      SOURCE_REPOSITORY="scratch"
    else
      SOURCE_REPOSITORY="staging"
    fi
  fi

  case "${SOURCE_REPOSITORY}" in
    scratch|staging) ;;
    *) fail "SOURCE_REPOSITORY invalide: ${SOURCE_REPOSITORY}. Valeurs autorisées: scratch, staging" ;;
  esac
fi

echo "Validation OK"
echo "ACTION=${ACTION}"
echo "NAME=${NAME}"
echo "TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
echo "TARGET_PROJECT=${TARGET_PROJECT}"

if [ "${ACTION}" = "deploy" ]; then
  echo "GROUP_ID=${GROUP_ID}"
  echo "VERSION=${VERSION}"
  echo "SOURCE_REPOSITORY=${SOURCE_REPOSITORY}"
fi
