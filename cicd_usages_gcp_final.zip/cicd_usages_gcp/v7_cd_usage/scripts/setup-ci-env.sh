#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

require_yq_value() {
  local var_name="$1"
  local value="$2"
  local source_file="$3"
  if [ -z "${value}" ] || [ "${value}" = "null" ]; then
    fail "${var_name} absent dans ${source_file}"
  fi
}

: "${TARGET_ENVIRONMENT:?Variable manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable manquante: NAME}"
: "${TARGET_PROJECT:?Variable manquante: TARGET_PROJECT}"
: "${GITLAB_OIDC_TOKEN:?OIDC token GitLab manquant}"
: "${ARTIFACTORY_USERNAME:?Variable GitLab manquante: ARTIFACTORY_USERNAME}"
: "${ARTIFACTORY_PASSWORD:?Variable GitLab manquante: ARTIFACTORY_PASSWORD}"

ENV_FILE="terraform/config/${TARGET_ENVIRONMENT}.yaml"
USAGE_FILE="usages/${TARGET_ENVIRONMENT}/${NAME}.yaml"

[ -f "${ENV_FILE}" ] || fail "Fichier env absent: ${ENV_FILE}"
[ -f "${USAGE_FILE}" ] || fail "Fichier usage absent: ${USAGE_FILE}"

export SOURCE_IMAGE_REGISTRY="$(yq -r '.ci.source_image_registry' "${ENV_FILE}")"
export SA_EMAIL="$(yq -r '.ci.wif_sa_email' "${ENV_FILE}")"
export WIF_PROVIDER="$(yq -r '.ci.wif_provider' "${ENV_FILE}")"
export GCP_PROJECT_ID="$(yq -r '.ci.gcp_project_id' "${ENV_FILE}")"
export TF_BACKEND_BUCKET="$(yq -r '.ci.bucket' "${ENV_FILE}")"
export GAR_PROJECT_ID="$(yq -r '.ci.gar_project_id' "${ENV_FILE}")"

require_yq_value "ci.source_image_registry" "${SOURCE_IMAGE_REGISTRY}" "${ENV_FILE}"
require_yq_value "ci.wif_sa_email" "${SA_EMAIL}" "${ENV_FILE}"
require_yq_value "ci.wif_provider" "${WIF_PROVIDER}" "${ENV_FILE}"
require_yq_value "ci.gcp_project_id" "${GCP_PROJECT_ID}" "${ENV_FILE}"
require_yq_value "ci.bucket" "${TF_BACKEND_BUCKET}" "${ENV_FILE}"
require_yq_value "ci.gar_project_id" "${GAR_PROJECT_ID}" "${ENV_FILE}"

# Domaine du state déduit depuis TARGET_PROJECT, pas depuis NAME.
# Exemple : TARGET_PROJECT=caa-data-domsin-dev-e7, TARGET_ENVIRONMENT=dev => domsin
PROJECT_BEFORE_ENV="${TARGET_PROJECT%-${TARGET_ENVIRONMENT}-*}"
if [ "${PROJECT_BEFORE_ENV}" = "${TARGET_PROJECT}" ]; then
  fail "Impossible de déduire le domaine depuis TARGET_PROJECT=${TARGET_PROJECT} avec TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
fi

export TF_BACKEND_DOMAIN="${PROJECT_BEFORE_ENV##*-}"
export TF_BACKEND_ENV="${TARGET_ENVIRONMENT}"
export TF_BACKEND_PREFIX="${TF_BACKEND_DOMAIN}/${TF_BACKEND_ENV}/${NAME}"

# Mot de passe Artifactory : support valeur brute ou base64.
if echo "${ARTIFACTORY_PASSWORD}" | base64 -d >/tmp/artifactory_token 2>/dev/null; then
  export JFROG_TOKEN="$(cat /tmp/artifactory_token)"
else
  export JFROG_TOKEN="${ARTIFACTORY_PASSWORD}"
fi
rm -f /tmp/artifactory_token

mkdir -p "${HOME}/.docker"
echo "${JFROG_TOKEN}" | docker login "${SOURCE_IMAGE_REGISTRY}" --username "${ARTIFACTORY_USERNAME}" --password-stdin

# WIF GitLab -> GCP.
# GCP_PROJECT_ID reste le projet CI/CD/WIF. Il est volontairement distinct de TARGET_PROJECT.
echo "${GITLAB_OIDC_TOKEN}" > "${CI_PROJECT_DIR}/token.jwt"
gcloud iam workload-identity-pools create-cred-config \
  "${WIF_PROVIDER}" \
  --service-account="${SA_EMAIL}" \
  --credential-source-file="${CI_PROJECT_DIR}/token.jwt" \
  --credential-source-type=text \
  --output-file="${CI_PROJECT_DIR}/credentials.json"

gcloud auth login --cred-file="${CI_PROJECT_DIR}/credentials.json" --quiet

# Impersonation centrale pour accéder au bucket tfstate et au GAR central.
# Le provider Terraform Google ré-impersonate ensuite le SA du projet usage pour les ressources applicatives.
export GOOGLE_APPLICATION_CREDENTIALS="${CI_PROJECT_DIR}/credentials.json"
export GOOGLE_IMPERSONATE_SERVICE_ACCOUNT="iac-deploy-usage-sa@${GCP_PROJECT_ID}.iam.gserviceaccount.com"

gcloud config set project "${GCP_PROJECT_ID}" --quiet
gcloud config set auth/impersonate_service_account "${GOOGLE_IMPERSONATE_SERVICE_ACCOUNT}" --quiet

cat > "${HOME}/.terraformrc" <<EOF_TERRAFORMRC
provider_installation {
  direct {
    exclude = ["registry.terraform.io/hashicorp/google","registry.terraform.io/hashicorp/google-beta","registry.terraform.io/kreuzwerker/docker","registry.terraform.io/hashicorp/random"]
  }
  network_mirror {
    include = ["registry.terraform.io/hashicorp/google","registry.terraform.io/hashicorp/google-beta","registry.terraform.io/kreuzwerker/docker","registry.terraform.io/hashicorp/random"]
    url = "${TERRAFORM_REGISTRY_MIRROR}"
  }
}
EOF_TERRAFORMRC

echo "Configuration CI OK"
echo "SOURCE_IMAGE_REGISTRY=${SOURCE_IMAGE_REGISTRY}"
echo "GCP_PROJECT_ID=${GCP_PROJECT_ID}"
echo "TARGET_PROJECT=${TARGET_PROJECT}"
echo "GAR_PROJECT_ID=${GAR_PROJECT_ID}"
echo "TF_BACKEND_BUCKET=${TF_BACKEND_BUCKET}"
echo "TF_BACKEND_PREFIX=${TF_BACKEND_PREFIX}"
echo "GOOGLE_IMPERSONATE_SERVICE_ACCOUNT=${GOOGLE_IMPERSONATE_SERVICE_ACCOUNT}"
