#!/usr/bin/env bash
set -euo pipefail

: "${GCP_PROJECT_ID:?Variable manquante: GCP_PROJECT_ID}"
: "${GAR_PROJECT_ID:?Variable manquante: GAR_PROJECT_ID}"
: "${REGION:=europe-west1}"

DEPLOY_SA="iac-deploy-usage-sa@${GCP_PROJECT_ID}.iam.gserviceaccount.com"

echo "Authentification Docker GAR via ${DEPLOY_SA}"
echo "GAR_PROJECT_ID=${GAR_PROJECT_ID}"

gcloud auth print-access-token --impersonate-service-account="${DEPLOY_SA}" \
  | docker login \
      --username oauth2accesstoken \
      --password-stdin \
      "${REGION}-docker.pkg.dev"
