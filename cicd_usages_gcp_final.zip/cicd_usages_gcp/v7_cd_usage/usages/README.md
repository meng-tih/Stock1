# Dossier usages

Les fichiers YAML de ce dossier sont générés par le pipeline à partir du template :

```text
templates/usage.yaml.tpl
```

Ils ne doivent pas être maintenus manuellement dans Git.
