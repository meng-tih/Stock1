# v7_cd_usage

Repo de déploiement CD GCP pour les usages CAAS.

Ce repo est déclenché par `v7_cd_usage_entrypoint` avec les variables déjà résolues :

```text
ACTION=deploy|destroy
TARGET_ENVIRONMENT=dev|int|rec
NAME=<identifiant complet de l'usage>
TARGET_PROJECT=<project id GCP de l'usage>
GROUP_ID=<groupId Maven / chemin Artifactory logique>     # requis en deploy
VERSION=<tag image Docker>                                # requis en deploy
SOURCE_REPOSITORY=scratch|staging                         # optionnel, déduit par défaut
```

## Rôle du repo

En mode `deploy`, le pipeline :

1. valide les variables d'entrée ;
2. génère `usages/<env>/<NAME>.yaml` depuis `templates/usage.yaml.tpl` ;
3. configure la WIF GitLab et l'impersonation GCP ;
4. initialise Terraform avec un state isolé par domaine, environnement et usage ;
5. lit l'image dans Artifactory `scratch` ou `staging` ;
6. pousse l'image vers GAR ;
7. déploie le Cloud Run Job et ses ressources associées.

En mode `destroy`, le pipeline :

1. génère le même fichier YAML d'usage avec des valeurs d'image neutres ;
2. calcule le même backend Terraform ;
3. exécute automatiquement le `terraform plan -destroy` ;
4. laisse le `terraform apply` de destruction en manuel.

## Environnements supportés

```text
dev
int
rec
```

## Règle de sourcing image

```text
dev     -> Artifactory scratch
int/rec -> Artifactory staging
```

Le repo ne fait pas de promote. L'image doit déjà exister dans le repository Artifactory attendu.

## Règle de nommage retenue

Le `NAME` envoyé à la CD est utilisé en entier comme identifiant de l'usage.

Exemples valides :

```text
sinfs
dsd-sinfs
ma-dsd-sinbdo-domsin
ma_dsd_sinbdo_domsin
```

Le script ne découpe plus `NAME` pour déterminer le domaine.

## Domaine GCP

Le domaine est déduit depuis le `TARGET_PROJECT`, juste avant l'environnement.

Exemple :

```text
TARGET_PROJECT     = caa-data-domsin-dev-e7
TARGET_ENVIRONMENT = dev
DOMAIN             = domsin
```

Cette règle permet de garder le domaine cohérent avec les project ids GCP, même si `NAME` ne contient pas le domaine.

## Backend Terraform

Le state est isolé par domaine, environnement et usage complet :

```text
gs://tfstate-caa-apps-usage-hprd/<domain>/<env>/<NAME>/default.tfstate
```

Exemple :

```text
NAME               = sinfs
TARGET_ENVIRONMENT = dev
TARGET_PROJECT     = caa-data-domsin-dev-e7

TF_BACKEND_PREFIX  = domsin/dev/sinfs
```

Autre exemple :

```text
NAME               = ma-dsd-sinbdo-domsin
TARGET_ENVIRONMENT = dev
TARGET_PROJECT     = caa-data-domsin-dev-e7

TF_BACKEND_PREFIX  = domsin/dev/ma-dsd-sinbdo-domsin
```

## Bucket applicatif

Le bucket est construit avec le project id sans suffixe technique, la région et le `NAME` complet.

Exemple :

```text
TARGET_PROJECT = caa-data-domsin-dev-e7
NAME           = sinfs
REGION         = europe-west1

BUCKET_NAME    = caa-data-domsin-dev-gcs-europe-west1-sinfs
```

Si `NAME` contient des underscores, ils sont remplacés par des tirets dans le nom du bucket, car GCS n'accepte pas `_` dans les noms de bucket.

## Impersonation GCP

Le pipeline utilise deux niveaux :

```text
WIF GitLab
  -> iac-wif-usage-sa@caa-cicd-usage-hprd-d6
  -> iac-deploy-usage-sa@caa-cicd-usage-hprd-d6
```

Le SA central `iac-deploy-usage-sa@caa-cicd-usage-hprd-d6` est utilisé pour accéder au bucket Terraform state et au GAR central.

Le provider Terraform Google impersonate ensuite le SA de déploiement du projet usage pour les ressources applicatives :

```text
iac-deploy-usage-sa@<TARGET_PROJECT>.iam.gserviceaccount.com
```

## Droits IAM attendus

Le repo GitLab `v7_cd_usage` doit être autorisé dans la WIF sur le SA :

```text
iac-wif-usage-sa@caa-cicd-usage-hprd-d6.iam.gserviceaccount.com
```

Le SA central doit pouvoir impersonate les SA applicatifs des projets usages :

```text
iac-deploy-usage-sa@caa-cicd-usage-hprd-d6
  -> roles/iam.serviceAccountTokenCreator
  -> iac-deploy-usage-sa@<TARGET_PROJECT>
```

Le SA applicatif doit avoir les droits nécessaires dans son projet usage : Cloud Run, Secret Manager, Artifact Registry selon le modèle cible, VPC/subnet en lecture, etc.

## Lancement manuel deploy

Exemple depuis GitLab :

```text
ACTION=deploy
TARGET_ENVIRONMENT=dev
NAME=sinfs
TARGET_PROJECT=caa-data-domsin-dev-e7
GROUP_ID=fr.caa.systemeentreprise.pilotage.ma
VERSION=0.0.15
```

`SOURCE_REPOSITORY` est optionnel : `scratch` est pris par défaut en `dev`, `staging` en `int` / `rec`.

## Lancement manuel destroy

Exemple depuis GitLab :

```text
ACTION=destroy
TARGET_ENVIRONMENT=dev
NAME=sinfs
TARGET_PROJECT=caa-data-domsin-dev-e7
```

Le `destroy_plan` est automatique. Le `destroy_apply` reste manuel.

## Variables GitLab à configurer

```text
ARTIFACTORY_USERNAME
ARTIFACTORY_PASSWORD
DOCKER_HUB_MIRROR
TERRAFORM_REGISTRY_MIRROR
```

`ARTIFACTORY_PASSWORD` peut être fourni en clair ou encodé en base64 : le script tente un décodage base64 puis retombe sur la valeur brute si besoin.
