data "google_compute_network" "vpc" {
  project = local.google_project
  name    = local.vpc_network_name
}

data "google_compute_subnetwork" "cloud_run_subnet" {
  project = local.google_project
  name    = local.cloud_run_subnet_name
  region  = local.config.region
}
