module "cloud_run_job" {
  source   = "https://registry.saas.cagip.group.gca/artifactory/api/vcs/downloadTag/github-remote/GoogleCloudPlatform/cloud-foundation-fabric/v49.0.0//*/modules/cloud-run-v2?ext=tar.gz&archive=tar.gz"
  for_each = local.usages

  project_id = local.google_project
  name       = "${replace(each.key, "_", "-")}-${lower(local.env_name)}"
  region     = local.config.region
  type       = "JOB"
  labels     = local.resource_tags

  deletion_protection = false

  service_account_config = {
    create = false
    email  = data.google_service_account.execution_sa[each.key].email
  }

  job_config = {
    max_retries = try(each.value.execution.max_retries, 0)
    timeout     = "${try(each.value.execution.timeout_seconds, 3600)}s"
  }

  revision = {
    vpc_access = {
      egress  = "ALL_TRAFFIC"
      network = data.google_compute_network.vpc.name
      subnet  = data.google_compute_subnetwork.cloud_run_subnet.name
    }
  }

  containers = {
    (each.key) = {
      image = "${local.config.region}-docker.pkg.dev/${local.gar_project_id}/${local.gar_repository}/${each.key}:${each.value.version}"
      env   = try(each.value.env, {})

      volume_mounts = {
        "config-volume" = "/app/config/secrets"
      }
    }
  }

  volumes = {
    "config-volume" = {
      secret = {
        name    = "config-${each.key}-${lower(local.env_name)}"
        path    = "input.json"
        version = "latest"
      }
    }
  }

  iam          = {}
  launch_stage = null

  depends_on = [
    docker_registry_image.push,
    module.secrets,
    data.google_service_account.execution_sa,
    data.google_compute_network.vpc,
    data.google_compute_subnetwork.cloud_run_subnet,
  ]
}
