variable "environment" {
  description = "Environnement de déploiement"
  type        = string

  validation {
    condition     = contains(["dev", "int", "rec"], var.environment)
    error_message = "environment must be one of: dev, int, rec"
  }
}

variable "usage_key" {
  description = "Usage à déployer. Doit correspondre au nom du fichier YAML généré sans extension."
  type        = string
}
