data "google_service_account" "execution_sa" {
  for_each   = local.usages
  account_id = local.execution_sa_account_id
  project    = local.google_project
}
