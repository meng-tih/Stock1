locals {
  environment = var.environment

  globals   = yamldecode(file("${path.module}/config/globals.yaml"))
  overrides = yamldecode(file("${path.module}/config/${local.environment}.yaml"))
  config    = merge(local.globals, local.overrides)

  usage_file = "${path.module}/../usages/${local.environment}/${var.usage_key}.yaml"
  usage      = yamldecode(file(local.usage_file))

  usages = {
    (var.usage_key) = local.usage
  }

  google_project = local.usage.google_project
  env_name       = local.usage.environment
  resource_tags  = local.usage.tags
  domain         = local.usage.domain

  vpc_network_name      = "${local.google_project}-vpc-custom"
  cloud_run_subnet_name = "${local.google_project}-sub-cloud-run-subnet"

  # Service account de déploiement existant dans le projet applicatif cible.
  # L'accès au bucket tfstate reste porté par le SA central configuré côté CI.
  impersonate_sa = "${local.config.naming.deploy_account_id}@${local.google_project}.iam.gserviceaccount.com"

  # Projet GAR central.
  gar_project_id = local.config.ci.gar_project_id

  # Repository GAR existant : domain-ar-caa-data-{domain}
  gar_repository = "${local.config.naming.gar_repository_prefix}-${local.domain}"

  # Service account d'exécution Cloud Run existant dans le projet applicatif cible.
  execution_sa_account_id = local.config.naming.cloudrun_execution_account_id
}
