module "secrets" {
  source   = "https://registry.saas.cagip.group.gca/artifactory/api/vcs/downloadTag/github-remote/GoogleCloudPlatform/cloud-foundation-fabric/v49.0.0//*/modules/secret-manager?ext=tar.gz&archive=tar.gz"
  for_each = local.usages

  project_id = local.google_project

  secrets = {
    "config-${each.key}-${lower(local.env_name)}" = {
      global_replica_locations = {
        europe-west1 = null
      }

      labels = local.resource_tags

      iam = {
        "roles/secretmanager.secretAccessor" = [
          "serviceAccount:${data.google_service_account.execution_sa[each.key].email}"
        ]
      }

      versions = {
        latest = {
          data    = jsonencode(try(each.value.default_inputs, {}))
          enabled = true
        }
      }
    }
  }

  depends_on = [data.google_service_account.execution_sa]
}
