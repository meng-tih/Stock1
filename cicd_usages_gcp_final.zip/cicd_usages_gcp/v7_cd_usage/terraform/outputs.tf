output "environment" {
  value = local.env_name
}

output "google_project" {
  value = local.google_project
}

output "gar_repository" {
  value = local.gar_repository
}

output "deployed_usages" {
  value = keys(local.usages)
}
