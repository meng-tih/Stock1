data "google_artifact_registry_repository" "gar_repo" {
  provider      = google.gar
  project       = local.gar_project_id
  location      = local.config.region
  repository_id = local.gar_repository
}

resource "docker_image" "source" {
  for_each = local.usages

  # Exemple : caas-shared-docker-staging-intranet.registry.../fr/caa/.../ma/ma-dsd-sinbdo-domsin:0.0.15
  name         = "${local.config.ci.source_image_registry}/${each.value.group_path}/${each.value.image_name}:${each.value.version}"
  keep_locally = true
}

resource "docker_tag" "target" {
  for_each = local.usages

  source_image = docker_image.source[each.key].name
  target_image = "${local.config.region}-docker.pkg.dev/${local.gar_project_id}/${local.gar_repository}/${each.key}:${each.value.version}"
}

resource "docker_registry_image" "push" {
  for_each = local.usages

  name          = docker_tag.target[each.key].target_image
  keep_remotely = true

  triggers = {
    source_sha = docker_image.source[each.key].repo_digest
  }
}
