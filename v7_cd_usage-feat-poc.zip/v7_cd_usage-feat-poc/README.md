# v7_cd_usage

Repo de déploiement CD GCP pour les usages CAAS.

## Rôle

Ce repo est déclenché par `v7_cd_usage_entrypoint` avec les variables résolues :

```text
TARGET_ENVIRONMENT
NAME
GROUP_ID
VERSION
TARGET_PROJECT
SOURCE_REPOSITORY
```

Il :

1. génère un fichier YAML d'usage depuis `templates/usage.yaml.tpl` ;
2. construit le chemin image Artifactory avec `GROUP_ID`, `NAME`, `VERSION` ;
3. pull l'image depuis Artifactory `scratch` ou `staging` ;
4. push l'image vers GAR/GCR ;
5. déploie le Cloud Run Job avec Terraform.

## Environnements supportés

```text
dev
int
rec
```

## Source image

```text
dev     -> scratch
int/rec -> staging
```

Le repo ne fait pas de promote. L'image doit déjà exister dans le repository Artifactory attendu.

## Service accounts attendus

Dans chaque project applicatif cible :

```text
iac-deploy-usage-sa@<TARGET_PROJECT>.iam.gserviceaccount.com
cicd-usage-cloudrun-sa@<TARGET_PROJECT>.iam.gserviceaccount.com
```

## Nommage bucket

Exemple :

```text
TARGET_PROJECT = caa-data-domsin-dev-e7
NAME           = ma-dsd-sinbdo-domsin
```

Résultat :

```text
caa-data-domsin-dev-gcs-europe-west1-sinbdo
```

Règle :

```text
project_prefix = TARGET_PROJECT sans le dernier suffixe technique
bucket         = <project_prefix>-gcs-europe-west1-<name>
```

Le script supporte `-` et `_` pour découper `NAME`.

## Variables GitLab à configurer

```text
ARTIFACTORY_USERNAME
ARTIFACTORY_PASSWORD
DOCKER_HUB_MIRROR
TERRAFORM_REGISTRY_MIRROR
```

`ARTIFACTORY_PASSWORD` peut être fourni en clair ou encodé en base64 : le script tente un décodage base64 puis retombe sur la valeur brute si besoin.
