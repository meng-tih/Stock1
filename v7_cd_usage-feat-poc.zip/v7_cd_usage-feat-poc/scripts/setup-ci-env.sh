#!/usr/bin/env bash
set -euo pipefail

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

: "${TARGET_ENVIRONMENT:?Variable manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable manquante: NAME}"
: "${GITLAB_OIDC_TOKEN:?OIDC token GitLab manquant}"
: "${ARTIFACTORY_USERNAME:?Variable GitLab manquante: ARTIFACTORY_USERNAME}"
: "${ARTIFACTORY_PASSWORD:?Variable GitLab manquante: ARTIFACTORY_PASSWORD}"
: "${TARGET_PROJECT:?Variable manquante: TARGET_PROJECT}"

ENV_FILE="terraform/config/${TARGET_ENVIRONMENT}.yaml"
GLOBAL_FILE="terraform/config/globals.yaml"
USAGE_FILE="usages/${TARGET_ENVIRONMENT}/${NAME}.yaml"

[ -f "${ENV_FILE}" ] || fail "Fichier env absent: ${ENV_FILE}"
[ -f "${USAGE_FILE}" ] || fail "Fichier usage absent: ${USAGE_FILE}"

export SOURCE_IMAGE_REGISTRY="$(yq -r '.ci.source_image_registry' "${ENV_FILE}")"
export SA_EMAIL="$(yq -r '.ci.wif_sa_email' "${ENV_FILE}")"
export WIF_PROVIDER="$(yq -r '.ci.wif_provider' "${ENV_FILE}")"
export GCP_PROJECT_ID="$(yq -r '.ci.gcp_project_id' "${ENV_FILE}")"
export TF_BACKEND_BUCKET="$(yq -r '.ci.bucket' "${ENV_FILE}")"
export GAR_PROJECT_ID="$(yq -r '.ci.gar_project_id' "${ENV_FILE}")"

PROJECT_BEFORE_ENV="${TARGET_PROJECT%-${TARGET_ENVIRONMENT}-*}"

if [ "$PROJECT_BEFORE_ENV" = "$TARGET_PROJECT" ]; then
  fail "Impossible de déduire le domaine depuis TARGET_PROJECT=${TARGET_PROJECT} avec TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
fi

export TF_BACKEND_DOMAIN="$(yq -r '.domain' "${USAGE_FILE}")"
export TF_BACKEND_ENV="$(yq -r '.environment' "${USAGE_FILE}")"
export TF_BACKEND_PREFIX="${TF_BACKEND_DOMAIN}/${TF_BACKEND_ENV}/${NAME}"

[ "${SOURCE_IMAGE_REGISTRY}" != "null" ] || fail "ci.source_image_registry absent dans ${ENV_FILE}"
[ "${SA_EMAIL}" != "null" ] || fail "ci.wif_sa_email absent dans ${ENV_FILE}"
[ "${WIF_PROVIDER}" != "null" ] || fail "ci.wif_provider absent dans ${ENV_FILE}"
[ "${GCP_PROJECT_ID}" != "null" ] || fail "ci.gcp_project_id absent dans ${ENV_FILE}"
[ "${TF_BACKEND_BUCKET}" != "null" ] || fail "ci.bucket absent dans ${ENV_FILE}"
[ "${GAR_PROJECT_ID}" != "null" ] || fail "ci.gar_project_id absent dans ${ENV_FILE}"

# Mot de passe Artifactory : support valeur brute ou base64.
if echo "${ARTIFACTORY_PASSWORD}" | base64 -d >/tmp/artifactory_token 2>/dev/null; then
  export JFROG_TOKEN="$(cat /tmp/artifactory_token)"
else
  export JFROG_TOKEN="${ARTIFACTORY_PASSWORD}"
fi
rm -f /tmp/artifactory_token

mkdir -p "${HOME}/.docker"
echo "${JFROG_TOKEN}" | docker login "${SOURCE_IMAGE_REGISTRY}" --username "${ARTIFACTORY_USERNAME}" --password-stdin

# WIF GitLab -> GCP
echo "${GITLAB_OIDC_TOKEN}" > "${CI_PROJECT_DIR}/token.jwt"
gcloud iam workload-identity-pools create-cred-config \
  "${WIF_PROVIDER}" \
  --service-account="${SA_EMAIL}" \
  --credential-source-file="${CI_PROJECT_DIR}/token.jwt" \
  --credential-source-type=text \
  --output-file="${CI_PROJECT_DIR}/credentials.json"

gcloud auth login --cred-file="${CI_PROJECT_DIR}/credentials.json" --quiet
gcloud config set project "${GCP_PROJECT_ID}" --quiet

export GOOGLE_APPLICATION_CREDENTIALS="${CI_PROJECT_DIR}/credentials.json"
export GOOGLE_IMPERSONATE_SERVICE_ACCOUNT="iac-deploy-usage-sa@${GCP_PROJECT_ID}.iam.gserviceaccount.com"

cat > "${HOME}/.terraformrc" <<EOF
provider_installation {
  direct {
    exclude = ["registry.terraform.io/hashicorp/google","registry.terraform.io/hashicorp/google-beta","registry.terraform.io/kreuzwerker/docker","registry.terraform.io/hashicorp/random"]
  }
  network_mirror {
    include = ["registry.terraform.io/hashicorp/google","registry.terraform.io/hashicorp/google-beta","registry.terraform.io/kreuzwerker/docker","registry.terraform.io/hashicorp/random"]
    url = "${TERRAFORM_REGISTRY_MIRROR}"
  }
}
EOF

echo "Configuration CI OK"
echo "SOURCE_IMAGE_REGISTRY=${SOURCE_IMAGE_REGISTRY}"
echo "GCP_PROJECT_ID=${GCP_PROJECT_ID}"
echo "GAR_PROJECT_ID=${GAR_PROJECT_ID}"
echo "TF_BACKEND_BUCKET=${TF_BACKEND_BUCKET}"
echo "TF_BACKEND_PREFIX=${TF_BACKEND_PREFIX}"
echo "GOOGLE_IMPERSONATE_SERVICE_ACCOUNT=${GOOGLE_IMPERSONATE_SERVICE_ACCOUNT}"
