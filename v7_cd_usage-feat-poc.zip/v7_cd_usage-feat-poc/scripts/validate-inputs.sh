#!/usr/bin/env bash
set -euo pipefail

ACTION="${ACTION:-deploy}"

fail() {
  echo "ERREUR - $*" >&2
  exit 1
}

case "$ACTION" in
  deploy|destroy)
    ;;
  *)
    fail "ACTION invalide: $ACTION. Valeurs autorisées: deploy, destroy"
    ;;
esac

: "${TARGET_ENVIRONMENT:?Variable obligatoire manquante: TARGET_ENVIRONMENT}"
: "${NAME:?Variable obligatoire manquante: NAME}"

case "$TARGET_ENVIRONMENT" in
  dev|int|rec)
    ;;
  *)
    fail "TARGET_ENVIRONMENT invalide: ${TARGET_ENVIRONMENT}. Valeurs autorisées: dev, int, rec"
    ;;
esac

if [ "$ACTION" = "deploy" ]; then
  : "${GROUP_ID:?Variable obligatoire manquante en deploy: GROUP_ID}"
  : "${VERSION:?Variable obligatoire manquante en deploy: VERSION}"
  : "${TARGET_PROJECT:?Variable obligatoire manquante en deploy: TARGET_PROJECT}"
  : "${SOURCE_REPOSITORY:?Variable obligatoire manquante en deploy: SOURCE_REPOSITORY}"
fi

if [ "$ACTION" = "destroy" ]; then
  : "${TARGET_PROJECT:?Variable obligatoire manquante en destroy: TARGET_PROJECT}"
fi

case "${TARGET_ENVIRONMENT}" in
  dev|int|rec) ;;
  *) fail "TARGET_ENVIRONMENT invalide: ${TARGET_ENVIRONMENT}. Valeurs autorisées: dev, int, rec" ;;
esac

if [ -z "${SOURCE_REPOSITORY:-}" ]; then
  if [ "${TARGET_ENVIRONMENT}" = "dev" ]; then
    SOURCE_REPOSITORY="scratch"
  else
    SOURCE_REPOSITORY="staging"
  fi
fi

case "${SOURCE_REPOSITORY}" in
  scratch|staging) ;;
  *) fail "SOURCE_REPOSITORY invalide: ${SOURCE_REPOSITORY}. Valeurs autorisées: scratch, staging" ;;
esac

echo "Validation OK"
echo "ACTION=${ACTION}"
echo "NAME=${NAME}"
if [ "$ACTION" = "deploy" ]; then
  echo "GROUP_ID=${GROUP_ID}"
  echo "VERSION=${VERSION}"
  echo "SOURCE_REPOSITORY=${SOURCE_REPOSITORY}"
fi
echo "TARGET_ENVIRONMENT=${TARGET_ENVIRONMENT}"
echo "TARGET_PROJECT=${TARGET_PROJECT}"
