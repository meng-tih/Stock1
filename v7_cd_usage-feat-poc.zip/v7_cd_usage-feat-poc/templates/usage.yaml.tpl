usage_name: "__NAME__"
image_name: "__IMAGE_NAME__"
group_id: "__GROUP_ID__"
group_path: "__GROUP_PATH__"
version: "__VERSION__"
domain: "__DOMAIN__"
environment: "__TARGET_ENVIRONMENT__"
google_project: "__TARGET_PROJECT__"
source_repository: "__SOURCE_REPOSITORY__"

execution:
  timeout_seconds: 3600
  max_retries: 1
  memory: "1Gi"
  cpu: "1"

env:
  LOG_LEVEL: "INFO"
  ENV_NAME: "__TARGET_ENVIRONMENT__"
  LOGGER_LEVEL: "info"
  BUCKET_NAME: "__BUCKET_NAME__"
  DEBUG: "false"

default_inputs: {}

permissions:
  create_dataset: false

secrets:
  - input_config

tags:
  environment: "__TARGET_ENVIRONMENT__"
  managed_by: "terraform"
  usage: "__NAME__"
  domain: "__DOMAIN__"
