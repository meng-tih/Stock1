terraform {
  required_version = ">= 1.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "= 7.12.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = "= 7.12.0"
    }
    docker = {
      source  = "kreuzwerker/docker"
      version = ">= 3.0.0"
    }
  }

  backend "gcs" {}
}

provider "google" {
  project                     = local.google_project
  region                      = local.config.region
  impersonate_service_account = local.impersonate_sa
}

provider "google-beta" {
  project                     = local.google_project
  region                      = local.config.region
  impersonate_service_account = local.impersonate_sa
}

provider "google" {
  alias                       = "gar"
  project                     = local.gar_project_id
  region                      = local.config.region
  impersonate_service_account = "${local.config.naming.deploy_account_id}@${local.config.ci.gcp_project_id}.iam.gserviceaccount.com"
}

provider "docker" {
  registry_auth {
    address     = local.config.ci.source_image_registry
    config_file = pathexpand("~/.docker/config.json")
  }

  registry_auth {
    address     = "${local.config.region}-docker.pkg.dev"
    config_file = pathexpand("~/.docker/config.json")
  }
}
