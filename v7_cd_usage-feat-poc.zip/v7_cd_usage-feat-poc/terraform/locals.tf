locals {
  environment = var.environment

  globals   = yamldecode(file("${path.module}/config/globals.yaml"))
  overrides = yamldecode(file("${path.module}/config/${local.environment}.yaml"))
  config    = merge(local.globals, local.overrides)

  usage_files = fileset("${path.module}/../usages/${local.environment}", "*.yaml")

  all_usages = {
    for f in sort(local.usage_files) :
    replace(f, ".yaml", "") => yamldecode(file("${path.module}/../usages/${local.environment}/${f}"))
  }

  usages = {
    for k, v in local.all_usages : k => v if k == var.usage_key
  }

  first_usage_key = keys(local.usages)[0]

  google_project = local.usages[local.first_usage_key].google_project
  env_name       = local.usages[local.first_usage_key].environment
  resource_tags  = local.usages[local.first_usage_key].tags
  domain         = local.usages[local.first_usage_key].domain

  vpc_network_name      = "${local.google_project}-vpc-custom"
  cloud_run_subnet_name = "${local.google_project}-sub-cloud-run-subnet"

  # Service account de déploiement existant dans le project applicatif cible.
  impersonate_sa = "${local.config.naming.deploy_account_id}@${local.google_project}.iam.gserviceaccount.com"

  # Projet GAR central.
  gar_project_id = local.config.ci.gar_project_id

  # Repository GAR existant : domain-ar-caa-data-{domain}
  gar_repository = "${local.config.naming.gar_repository_prefix}-${local.domain}"

  # Service account d'exécution Cloud Run existant dans le project applicatif cible.
  execution_sa_account_id = local.config.naming.cloudrun_execution_account_id
}
